function varargout = Gravity_drained_tank(varargin)
% GRAVITY_DRAINED_TANK MAIN_TANK_INITIAL_LEVEL_HIDDEN-file for Gravity_drained_tank.fig
%      GRAVITY_DRAINED_TANK, by itself, creates a new GRAVITY_DRAINED_TANK or raises the existing
%      singleton*.
%
%      H = GRAVITY_DRAINED_TANK returns the handle to a new GRAVITY_DRAINED_TANK or the handle to
%      the existing singleton*.
%
%      GRAVITY_DRAINED_TANK('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in GRAVITY_DRAINED_TANK.MAIN_TANK_INITIAL_LEVEL_HIDDEN with the given input arguments.
%
%      GRAVITY_DRAINED_TANK('Property','Value',...) creates a new GRAVITY_DRAINED_TANK or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Gravity_drained_tank_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Gravity_drained_tank_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the Simulate to help Gravity_drained_tank

% Last Modified by GUIDE v2.5 12-Sep-2012 11:19:33

% Begin initialization code - DO NOT EDIT


gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Gravity_drained_tank_OpeningFcn, ...
                   'gui_OutputFcn',  @Gravity_drained_tank_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Gravity_drained_tank is made visible.
function Gravity_drained_tank_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Gravity_drained_tank (see VARARGIN)

% Choose default command line output for Gravity_drained_tank
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes Gravity_drained_tank wait for user Simulate (see UIRESUME)
% uiwait(handles.axes3);

           axes(handles.axes9)
            

% first step is to set initial pictures on appropirate axes
axes(handles.axes6) 
%concentrates on a axes 6 ! 

   moon = imread('tank49.jpg');
imshow(moon)


axes(handles.axes11) 
%concentrates on a axes 6 ! 

   moon = imread('shiraz_uni_english.jpg');
imshow(moon)



   
   axes(handles.axes8)
   moon = imread('tanku64.jpg');
imshow(moon)
    axes(handles.axes9)
   moon = imread('gheichi.jpg');
imshow(moon)
%    
   axis(handles.axes1,[0 600 35 60])
    axis(handles.axes10,[0 600 10 25])
   set(handles.axes10,'xtick',[])
% --- Outputs from this function are returned to the command line.
function varargout = Gravity_drained_tank_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes during object creation, after setting all properties.



% --- Executes during object creation, after setting all properties.
function axes1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to axes1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: place code in OpeningFcn to populate axes1
function axes2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to axes2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: place code in OpeningFcn to populate axes2

% --- Executes on selection change in cntr_menu.
function cntr_menu_Callback(hObject, eventdata, handles)
% hObject    handle to cntr_menu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns cntr_menu contents as cell array
%        contents{get(hObject,'Value')} returns selected item from cntr_menu


% visible or invisible things for manual mode P only etc : 

% manual mode:
if get(handles.cntr_menu,'value')==1
     axes(handles.axes9)
    imshow('gheichi.jpg',handles.axes9)
set(handles.open_or_closed_loop_level_static,'string','Open Loop Level: ');
set(handles.input_static,'visible','on');
set(handles.inlet_flowrate_edit,'visible','on');
set(handles.gc_static2,'visible','off');
set(handles.text72,'visible','off');
set(handles.text75,'visible','off');
set(handles.line_in_gc,'visible','off');
set(handles.text73,'visible','off');
set(handles.text69,'visible','off');
set(handles.controller_bias_static,'visible','off');
set(handles.controller_bias_edit,'visible','off');
set(handles.text74,'visible','off');
set(handles.set_point_static,'visible','off');
set(handles.set_point_edit,'visible','off');
set(handles.set_point_edit,'visible','off');
% set(handles.contoroller_gain_text_paramaters,'visible','off');
set(handles.controller_gain_edit,'visible','off');
% set(handles.reset_time_text_paramaters,'visible','off');
set(handles.reset_or_derive_time_edit,'visible','off');
set(handles.derive_time_edit,'visible','off');
% set(handles.derive_time_text_paramaters,'visible','off');
% set(handles.gc_static,'visible','off');
% set(handles.pid_static_text,'visible','off');
end
% P only:
if get(handles.cntr_menu,'value')==2  
set(handles.open_or_closed_loop_level_static,'string','Closed Loop Level: ');
set(handles.input_static,'visible','off');
set(handles.gc_static2,'visible','on');
set(handles.text69,'visible','off');
% set(handles.text69,'string',' ( 1 + ');
set(handles.line_in_gc,'visible','off');
set(handles.controller_bias_static,'visible','on');
set(handles.controller_bias_edit,'visible','on');
set(handles.text72,'visible','off');
set(handles.text73,'visible','off');
set(handles.text75,'visible','off');
set(handles.text74,'visible','off');
set(handles.inlet_flowrate_edit,'visible','off');
set(handles.set_point_static,'visible','on');
set(handles.set_point_edit,'visible','on');
% set(handles.contoroller_gain_text_paramaters,'visible','on');
set(handles.controller_gain_edit,'visible','on');
% set(handles.reset_time_text_paramaters,'visible','off');
set(handles.reset_or_derive_time_edit,'visible','off');
% set(handles.gc_static,'visible','on');
set(handles.derive_time_edit,'visible','off');
% set(handles.derive_time_text_paramaters,'visible','off');
% set(handles.pid_static_text,'string',' Kc ');
% set(handles.pid_static_text,'visible','on');
end
% I only:
if get(handles.cntr_menu,'value')==3
%  imshow('tank2.tif')
set(handles.open_or_closed_loop_level_static,'string','Closed Loop Level: ');
set(handles.input_static,'visible','off');
set(handles.inlet_flowrate_edit,'visible','off');
set(handles.gc_static2,'visible','on');
set(handles.set_point_static,'visible','on');
set(handles.text69,'visible','on');
set(handles.line_in_gc,'visible','on');
set(handles.controller_bias_static,'visible','off');
set(handles.controller_bias_edit,'visible','off');
set(handles.text73,'visible','on');
set(handles.text73,'string',')');
set(handles.text75,'visible','off');
set(handles.text72,'visible','on');
set(handles.text74,'visible','on');
set(handles.text69,'string',' ( ');
set(handles.set_point_edit,'visible','on');
% set(handles.contoroller_gain_text_paramaters,'visible','on');
set(handles.controller_gain_edit,'visible','on');
% set(handles.reset_time_text_paramaters,'visible','on');
set(handles.reset_or_derive_time_edit,'visible','on');
% set(handles.gc_static,'visible','on');
set(handles.derive_time_edit,'visible','off');
% set(handles.derive_time_text_paramaters,'visible','off');
% set(handles.pid_static_text,'string',' Kc ( 1/Ti*s ) ');
% set(handles.pid_static_text,'visible','on');
end
% PI
if get(handles.cntr_menu,'value')==4
%  imshow('tank2.tif')
set(handles.open_or_closed_loop_level_static,'string','Closed Loop Level: ');
set(handles.input_static,'visible','off');
set(handles.inlet_flowrate_edit,'visible','off');
set(handles.gc_static2,'visible','on');
set(handles.set_point_static,'visible','on');
set(handles.controller_bias_static,'visible','off');
set(handles.controller_bias_edit,'visible','off');
set(handles.line_in_gc,'visible','on');
set(handles.text72,'visible','on');
set(handles.text69,'visible','on');
set(handles.text74,'visible','on');
set(handles.text73,'visible','on');
set(handles.text73,'string',')');
set(handles.text69,'string',' ( 1+ ');
set(handles.set_point_edit,'visible','on');
% set(handles.contoroller_gain_text_paramaters,'visible','on');
set(handles.controller_gain_edit,'visible','on');
% set(handles.reset_time_text_paramaters,'visible','on');
set(handles.text75,'visible','off');
set(handles.reset_or_derive_time_edit,'visible','on');
set(handles.derive_time_edit,'visible','off');
% set(handles.derive_time_text_paramaters,'visible','off');
% set(handles.gc_static,'visible','on');
% set(handles.pid_static_text,'string',' Kc ( 1 + 1/Ti*s ) ');
% set(handles.pid_static_text,'visible','on');
end
% PID
if get(handles.cntr_menu,'value')==5
%  imshow('tank2.tif')
set(handles.open_or_closed_loop_level_static,'string','Closed Loop Level: ');
set(handles.input_static,'visible','off');
set(handles.inlet_flowrate_edit,'visible','off');
set(handles.set_point_static,'visible','on');
set(handles.gc_static2,'visible','on');
set(handles.text69,'visible','on');
set(handles.text69,'string',' ( 1+ ');
set(handles.controller_bias_static,'visible','off');
set(handles.controller_bias_edit,'visible','off');
set(handles.text72,'visible','on');
set(handles.text73,'visible','on');
set(handles.text75,'visible','on');
set(handles.text74,'visible','on');
set(handles.text73,'string','+');
set(handles.line_in_gc,'visible','on');
set(handles.set_point_edit,'visible','on');
% set(handles.contoroller_gain_text_paramaters,'visible','on');
set(handles.controller_gain_edit,'visible','on');
% set(handles.reset_time_text_paramaters,'visible','on');
% set(handles.reset_time_text_paramaters,'string','Reset Time (Ti):');
set(handles.reset_or_derive_time_edit,'visible','on');
set(handles.derive_time_edit,'visible','on');
% set(handles.derive_time_text_paramaters,'visible','on');
% set(handles.gc_static,'visible','on');
% set(handles.pid_static_text,'string','Kc (1+ 1/Ti*s+ Td*s )');
% set(handles.pid_static_text,'visible','on');
end


% --- Executes during object creation, after setting all properties.
function cntr_menu_CreateFcn(hObject, eventdata, handles)
% hObject    handle to cntr_menu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function inlet_flowrate_edit_Callback(hObject, eventdata, handles)
% hObject    handle to inlet_flowrate_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of inlet_flowrate_edit as text
%        str2double(get(hObject,'String')) returns contents of inlet_flowrate_edit as a double


% --- Executes during object creation, after setting all properties.
function inlet_flowrate_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to inlet_flowrate_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function dis_flowrate_Callback(hObject, eventdata, handles)
% hObject    handle to dis_flowrate (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of dis_flowrate as text
%        str2double(get(hObject,'String')) returns contents of dis_flowrate as a double


% --- Executes during object creation, after setting all properties.
function dis_flowrate_CreateFcn(hObject, eventdata, handles)
% hObject    handle to dis_flowrate (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in Simulate.
function Simulate_Callback(hObject, eventdata, handles)
% hObject    handle to Simulate (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global inlet
global dis
global end_simulation_time
global sample_rate
global pause_time
global t t_sim
global y Y
global step_difference_for_modeling
global y_memory
global inlet_setpoint_memory
global controller_output_memory
global setpoint_memory
% kharej kardan az halate ehtemali stop! 
set(handles.stop_pushbutton_hidden,'string',0);
set(handles.flag_for_no_y_used_for_error,'string',1);
% It means the user has clicked Simulate at least once and we have y

 set(handles.axes10,'xtick',[])


 high_level_alarm=str2double(get(handles.high_alarm_hidden,'string'));
 low_level_alarm=str2double(get(handles.low_alarm_hidden,'string'));
 
 
set(handles.measured_data_text,'visible' , 'off' );
set(handles.estimated_model_text,'visible' , 'off' );
 
% we are going to update new input value
    inlet=str2double(get(handles.inlet_flowrate_edit,'string'))
    previous_inlet=str2double(get(handles.input_hidden,'string'));
    set(handles.input_hidden,'string',inlet);
    step_difference_for_modeling=inlet-previous_inlet;
    
    if str2double(get(handles.flag_for_compare_mode,'string'))==1
    end
    
    
    % max inlet error : 
    if inlet>25
        errordlg('Process input should be less than 25 CM^3/sec ', ' Error: ');
        set(handles.inlet_flowrate_edit,'string',25)
        plot(handles.axes1,0,0)
        return
    end
    % min inlet error:
    if inlet<1
        errordlg('Process input should be more than 1 CM^3/sec ', ' Error: ');
        set(handles.inlet_flowrate_edit,'string',1)
        plot(handles.axes1,0,0)
        return
    end

    dis=str2double(get(handles.dis_flowrate,'string'))
    
    % max disturbance error : 
    if dis>10
        errordlg('Maximum Process disturbance is 10 CM^3/sec ', ' Error: ');
        set(handles.dis_flowrate,'string',10)
        plot(handles.axes1,0,0)
        return
    end
    % max disturbance error : 
    if dis<0
        errordlg('Minimum Process disturbance is 0 CM^3/sec ', ' Error: ');
        set(handles.dis_flowrate,'string',0)
        plot(handles.axes1,0,0)
        return
    end
    
    
    set(handles.inlet_flowrate_static,'string',inlet)
set(handles.outlet_flowrate,'string',inlet-dis)

% reading : start_simulation_hidden
%end_time_hidden
%   sample_rate_hidden
%   pause_time_hidden
start_simulation_time=str2double(get(handles.start_simulation_hidden,'string'));
end_simulation_time=str2double(get(handles.end_time_hidden,'string'));
sample_rate=str2double(get(handles.sample_rate_hidden,'string'));
pause_time=str2double(get(handles.pause_time_hidden,'string'));

    



%%% title name : 
if get(handles.cntr_menu,'value')==1
     set(handles.axes10_title,'string','Manual Input (cm^3/sec) :');
end
if get(handles.cntr_menu,'value')~=1
     set(handles.axes10_title,'string','Controller Output (cm^3/sec) :');
end
    
 %%%%%%%%%%%% manual mode :    
 
if get(handles.cntr_menu,'value')==1

%reading initial level:
upper_tank_initial_level=str2double(get(handles.upper_tank_initial_level_hidden,'string'));
main_tank_initial_level=str2double(get(handles.main_tank_initial_level_hidden,'string'));

% solving:
    [t,y]=ode45(@myfun,[0:sample_rate:end_simulation_time],[upper_tank_initial_level main_tank_initial_level]);

    
    %inital level update for next simulation
      % it means we are not in compare mode and we should update initial
  % values:
  if str2double(get(handles.flag_for_compare_mode,'string'))==0
    % write initial values for next use when we are not in compare mode: 
          set(handles.upper_tank_initial_level_hidden,'string',y(size(y,1),1))
          set(handles.main_tank_initial_level_hidden,'string',y(size(y,1),2))
  end
    
    % if we are in compare mode the graph should be hold on
    % but if we aren`t it should be cleared:
    if str2double(get(handles.flag_for_compare_mode,'string'))==1
     hold(handles.axes1,'on')
     hold(handles.axes10,'on')
    end
      if str2double(get(handles.flag_for_compare_mode,'string'))==0
      hold(handles.axes1,'off')
      cla(handles.axes1,'reset')
      cla(handles.axes10,'reset')
      end

      previous_upper_tank_level=0;
      previous_main_tank_level=0;
      
    % plotting:
    
    % if it is not the first time we click on simulate , so we have
    % y_memory form previous simulation :
    if str2double(get(handles.simulation_counter,'string'))~=0 
       hold(handles.axes1,'on')
       time_for_history_draw=[start_simulation_time:sample_rate:0];
        plot(handles.axes1,time_for_history_draw,[y_memory((length(y_memory)-length(time_for_history_draw)+1):length(y_memory))],'b.:','markersize',5)
        axis(handles.axes1,[start_simulation_time end_simulation_time real(min(y(:,2)))-10 real(max(y(:,2)))+10])
        hold(handles.axes10,'on')
         if str2double(get(handles.contoller_output_counter,'string'))==0
             % it means the user has never used closed loop!
        plot(handles.axes10,time_for_history_draw,[linspace(inlet_setpoint_memory,inlet_setpoint_memory,length(time_for_history_draw))])
         plot(handles.axes10,[0 0],[inlet_setpoint_memory inlet])
        end 
        if str2double(get(handles.contoller_output_counter,'string'))~=0
             % it means the user has at least once used closed loop!
            set(handles.contoller_output_counter,'string',0)
            plot(handles.axes10,time_for_history_draw,[controller_output_memory((length(controller_output_memory)-length(time_for_history_draw)+1):length(controller_output_memory))],'b.:','markersize',5)
        end
       
       
        axis(handles.axes10,[start_simulation_time end_simulation_time 1 27])
        plot(handles.axes10,[t(1) t(length(t))],[inlet inlet]);
    end
    % but if it is the first time we simulate , it should draw for level 49
    % and inlet 20
    level_main_tank=str2double(get(handles.level_static,'string'));
    inlet_for_first_simulate=str2double(get(handles.inlet_flowrate_static,'string'));
    if str2double(get(handles.simulation_counter,'string'))==0 
        hold(handles.axes1,'on')
        
        time_for_history_draw=[start_simulation_time:sample_rate:0];
        plot(handles.axes1,time_for_history_draw,[linspace( level_main_tank, level_main_tank,length(time_for_history_draw))],'b.:','markersize',5)
        axis(handles.axes1,[start_simulation_time end_simulation_time real(min(y(:,2)))-10 real(max(y(:,2)))+10])
        hold(handles.axes10,'on')
        plot(handles.axes10,time_for_history_draw,[linspace(inlet_for_first_simulate,inlet_for_first_simulate,length(time_for_history_draw))])
        plot(handles.axes10,[0 0],[inlet_for_first_simulate inlet])
        axis(handles.axes10,[start_simulation_time end_simulation_time 1 27])
        plot(handles.axes10,[t(1) t(length(t))],[inlet inlet]);
    end
    
    hold(handles.axes10,'off')
    
    
     
    for i=min(find(t>start_simulation_time)):length(t)
         
        if i>abs(start_simulation_time/sample_rate)
%         set(handles.stop_pushbutton,'visible','on');
        end
      axis(handles.axes1,[start_simulation_time end_simulation_time real(min(y(:,2)))-10 real(max(y(:,2)))+10])
       hold(handles.axes1,'on')
    plot(handles.axes1,t(i),real(y(i,2)),'b.:','markersize',5)
%     axis(handles.axes1,[start_simulation_time-200 end_simulation_time real(min(y(:,2)))-10 real(max(y(:,2)))+10])
    
% making the name for picture and set it to axes :
% to make the program faster we compare previous level with current one:
%main tank:
if floor(real(y(i,2)))~= previous_main_tank_level
picname=strcat('tank',num2str(floor(real(y(i,2)))),'.jpg');
axes(handles.axes6);
imread(picname);
imshow(picname);
% hold gheichi! :
axes(handles.axes9)
hold on

pause(0.00001)
  
end
 previous_main_tank_level=floor(real(y(i,2)));
 % upper tank:
if floor(real(y(i,1)))~=previous_upper_tank_level
picname=strcat('tanku',num2str(floor(real(y(i,1)))),'.jpg');
axes(handles.axes8);
imread(picname);
imshow(picname);
% hold gheichi! :
axes(handles.axes9)
hold on
pause(0.00001)
end  
previous_upper_tank_level=floor(real(y(i,1)));
    
    
             % alarms:
        if real(y(i,2))>high_level_alarm
            set(handles.high_alarm,'visible','on')
            pause(0.03)
            set(handles.high_alarm,'visible','off')
        end

        if real(y(i,2))<low_level_alarm
            set(handles.low_alarm,'visible','on')
            pause(0.03)
            set(handles.low_alarm,'visible','off')
        end
      
    %writing levels and outlet:
    set(handles.level_static,'string',sprintf('%0.2f',real(y(i,2))))
    set(handles.level_static_upper_tank,'string',sprintf('%0.2f',real(y(i,1))))
    set(handles.outlet_flowrate,'string',sprintf('%0.2f',inlet-dis))

    % sprintf has been used to select 2 floating point to show
    set(handles.time_static,'string',sprintf('%0.2f',t(i)));
   
         hold(handles.axes1,'on')
               pause(pause_time)
               
               % checking to see if stop button has been pressed or not
         % stop check:
                if  str2double(get(handles.stop_pushbutton_hidden,'string'))==1;
                    set(handles.stop_pushbutton,'visible','off');
                    
                    y_memory=y(1:i,2);
                    inlet_setpoint_memory=inlet;
                    % if we are not in compare mode levels should be
                    % updatetd after stop button pressed but not for
                    % otherwise:
                     
                        if str2double(get(handles.flag_for_compare_mode,'string'))==0
                           set(handles.upper_tank_initial_level_hidden,'string',y(size(y,1),1))
                           set(handles.main_tank_initial_level_hidden,'string',y(size(y,1),2))
                        end

                    return
                end
                
               
                
    end
    
    % invisblize stop button: 
    set(handles.stop_pushbutton,'visible','off');
      
    % storage of previouse variavles for next plot
    y_memory=y(:,2);
    inlet_setpoint_memory=inlet;

end





% P only

if get(handles.cntr_menu,'value')==2
    % initial values: 
         upper_tank_initial_level=str2double(get(handles.upper_tank_initial_level_hidden,'string'));
main_tank_initial_level=str2double(get(handles.main_tank_initial_level_hidden,'string'));
% slider initial value:
set(handles.slider3,'value',main_tank_initial_level/100)

%     set(handles.stop_pushbutton,'visible','on');
    
%     t_sim=start_simulation_time:sample_rate:end_simulation_time;
      t_sim=0:sample_rate:end_simulation_time
    
       y=[0 0;upper_tank_initial_level main_tank_initial_level];
    Y=0;

    setpoint=str2double(get(handles.set_point_edit,'string'));
    
     if setpoint>100 || setpoint<2
      uiwait(errordlg('SetPoint Can Be Between 2 and 100 CM . '));
      return
     end
    
    controllergain=str2double(get(handles. controller_gain_edit,'string')); 
    
    
    % if we are in compare mode the graph should be hold on
    % but if we aren`t it should be cleared:
    if str2double(get(handles.flag_for_compare_mode,'string'))==1
     hold(handles.axes1,'on')
     hold(handles.axes10,'on')
    end
      if str2double(get(handles.flag_for_compare_mode,'string'))==0
      hold(handles.axes1,'off')
      hold(handles.axes10,'off')
      cla(handles.axes1,'reset')
      cla(handles.axes10,'reset')
      end
      
      
           % reading current inlet:
%      initial_inlet=str2double(get(handles.inlet_flowrate_static,'string'));
      
     % previous levels for comparing with current ones for pictures:
     previous_main_tank_level=0;
     previous_upper_tank_level=0;
     
     
     
     
     
     
         % if it is not the first time we click on simulate , so we have
    % y_memory form previous simulation :
    if str2double(get(handles.simulation_counter,'string'))~=0 
       hold(handles.axes1,'on')
       time_for_history_draw=[start_simulation_time:sample_rate:0];
        plot(handles.axes1,time_for_history_draw,[y_memory((length(y_memory)-length(time_for_history_draw)+1):length(y_memory))],'b.:','markersize',5)
        axis(handles.axes1,[start_simulation_time end_simulation_time real(min(y(:,2)))-10 real(max(y(:,2)))+10])
        hold(handles.axes10,'on')
        
      
        if str2double(get(handles.contoller_output_counter,'string'))~=0
        plot(handles.axes10,time_for_history_draw,[controller_output_memory((length(controller_output_memory)-length(time_for_history_draw)+1):length(controller_output_memory))],'b.:','markersize',5)
        plot(handles.axes1,[start_simulation_time 0],[setpoint_memory setpoint_memory],'m')
         plot(handles.axes1,[0 0],[setpoint_memory setpoint],'m')
%         plot(handles.axes10,[0 0],[inlet_setpoint_memory inlet])
        end
        if str2double(get(handles.contoller_output_counter,'string'))==0
        plot(handles.axes10,time_for_history_draw,[linspace(inlet_setpoint_memory,inlet_setpoint_memory,length(time_for_history_draw))])
%         plot(handles.axes10,[0 0],[inlet_setpoint_memory inlet])
        end
        
        axis(handles.axes10,[start_simulation_time end_simulation_time 1 27])
%         plot(handles.axes10,[t(1) t(length(t))],[inlet inlet]);
    end
    % but if it is the first time we simulate , it should draw for level 49
    % and inlet 20
    level_main_tank=str2double(get(handles.level_static,'string'));
    inlet_for_first_simulate=str2double(get(handles.inlet_flowrate_static,'string'));
    if str2double(get(handles.simulation_counter,'string'))==0 
        hold(handles.axes1,'on')
        
        time_for_history_draw=[start_simulation_time:sample_rate:0];
        plot(handles.axes1,time_for_history_draw,[linspace( level_main_tank, level_main_tank,length(time_for_history_draw))],'b.:','markersize',5)
        axis(handles.axes1,[start_simulation_time end_simulation_time real(min(y(:,2)))-10 real(max(y(:,2)))+10])
        hold(handles.axes10,'on')
        plot(handles.axes10,time_for_history_draw,[linspace(inlet_for_first_simulate,inlet_for_first_simulate,length(time_for_history_draw))])
        plot(handles.axes10,[0 0],[inlet_for_first_simulate inlet])
        axis(handles.axes10,[start_simulation_time end_simulation_time 1 27])
        plot(handles.axes10,[t(1) t(length(t))],[inlet inlet]);
    end
    

     
    inlet_store=[]; 
  for i=1:length(t_sim)
      
        if i>abs(start_simulation_time/sample_rate)
%         set(handles.stop_pushbutton,'visible','on');
        end
 axis(handles.axes1,[start_simulation_time end_simulation_time -1 100])
 axis(handles.axes10,[start_simulation_time end_simulation_time 1 27])

 % P concept:
error=setpoint-real(y(2,2));
% inlet= initial_inlet+controllergain*error;
% reading controller bias :
controll_bias=str2double(get(handles.controller_bias_edit,'string'));
inlet= controll_bias+controllergain*error;
inlet_store=[inlet_store inlet]; 
         if inlet<0
         inlet=1;
         end
           if inlet>25
           inlet=25;
          end
        
        set(handles.inlet_flowrate_static,'string',sprintf('%0.2f',inlet));

        
        tspan=[t_sim(i) t_sim(i)+sample_rate t_sim(i)+2*sample_rate];

        % solving:
          % it seems that ode23 is the fastest in ODE`s..
         [t,y]=ode23(@myfun2,tspan,[y(2,1) y(2,2)]);

        Y=[Y real(y(2,2))];
    
        % full tank check:
        if y(2,1)>100
            y(2,1)=100;
            set(handles.upper_tank_full,'visible','on');
             pause(0.05)
            set(handles.upper_tank_full,'visible','off')
        end
        
          %empty tank check:
        % main tank:
        if real(y(2,2))<3
            y(2,2)=3;
        end
        % upper tank:
        if real(y(2,1))<3
            y(2,1)=3;
        end
        
        
        % alarms:
        if real(y(2,2))>high_level_alarm 
            set(handles.high_alarm,'visible','on')
            pause(0.03)
            set(handles.high_alarm,'visible','off')
        end

        if real(y(2,2))<low_level_alarm
            set(handles.low_alarm,'visible','on')
            pause(0.03)
            set(handles.low_alarm,'visible','off')
        end
      
        

% making the name for picture and set it to axes :
% to make the program faster we compare previous level with current one:
%main tank:
if floor(real(y(2,2)))~= previous_main_tank_level
picname=strcat('tank',num2str(floor(real(y(2,2)))),'.jpg');
axes(handles.axes6);
imread(picname);
imshow(picname);
pause(0.00001)
end
 previous_main_tank_level=floor(real(y(2,2)));
 % upper tank:
if floor(real(y(2,1)))~=previous_upper_tank_level
picname=strcat('tanku',num2str(floor(real(y(2,1)))),'.jpg');
axes(handles.axes8);
imread(picname);
imshow(picname);
pause(0.00001)
end  
previous_upper_tank_level=floor(real(y(2,1)));

        
        
        % writing levels and outlet:
            set(handles.level_static,'string',sprintf('%0.2f',Y(i)))
            set(handles.level_static_upper_tank,'string',sprintf('%0.2f',real(y(2,1))))
            set(handles.outlet_flowrate,'string',sprintf('%0.2f',inlet-dis))
            
            % slider:
            % it seems when i=1 we get a (0,0) in plot! i don`t know why!!
            if i~=1
            set(handles.slider3,'value',Y(i)/100)
            end
            
            
        % ploting:
      plot(handles.axes1,t_sim(i),Y(i),'b.:','markersize',5)
      plot(handles.axes10,t_sim(i),inlet,'b.:','markersize',5)
      if i==1
       plot(handles.axes1,[0 end_simulation_time],[setpoint setpoint],'m');
      end
      hold(handles.axes1,'on')
      hold(handles.axes10,'on')
      
%        axis(handles.axes10,[start_simulation_time end_simulation_time 1 27])
      
      
        %writing time static
        set(handles.time_static,'string',sprintf('%0.2f',t_sim(i)));
    
        
        
      % stop check:
                if  str2double(get(handles.stop_pushbutton_hidden,'string'))==1;
                    set(handles.stop_pushbutton,'visible','off');
                   
                    % if we are not in compare mode levels should be
                    % updatetd after stop button pressed but not for
                    % otherwise:
                        if str2double(get(handles.flag_for_compare_mode,'string'))==0
                           set(handles.upper_tank_initial_level_hidden,'string',y(size(y,1),1))
                           set(handles.main_tank_initial_level_hidden,'string',y(size(y,1),2))
                        end

                    return
                end
                
                
                
                
      pause(0.000001)
  end
    
  
  % it means we are not in compare mode and we should update initial
  % values:
  if str2double(get(handles.flag_for_compare_mode,'string'))==0
    % write initial values for next use: 
          set(handles.upper_tank_initial_level_hidden,'string',y(size(y,1),1))
    set(handles.main_tank_initial_level_hidden,'string',y(size(y,1),2))

  end
   
    
    % invisblize stop button: 
    set(handles.stop_pushbutton,'visible','off');
    y_memory=Y;
    
    inlet_setpoint_memory=setpoint;
    controller_output_memory=inlet_store;
    setpoint_memory=setpoint;
    
    % now we want to know how many times we have had controller output ( the number of times we had closed loop ! :
    contoller_output_counter=str2double(get(handles.contoller_output_counter,'string'));
    contoller_output_counter=contoller_output_counter+1;
    set(handles.contoller_output_counter,'string',contoller_output_counter);
    
    
end





% I only:

if get(handles.cntr_menu,'value')==3
    error=0;
    % initial values: 
         upper_tank_initial_level=str2double(get(handles.upper_tank_initial_level_hidden,'string'));
         main_tank_initial_level=str2double(get(handles.main_tank_initial_level_hidden,'string'));
% slider initial value:
set(handles.slider3,'value',main_tank_initial_level/100)
% stop button:
%     set(handles.stop_pushbutton,'visible','on');
    
    t_sim=0:sample_rate:end_simulation_time;

    
       y=[0 0;upper_tank_initial_level main_tank_initial_level];
       Y=0;

    % reading setpoint:
    setpoint=str2double(get(handles.set_point_edit,'string'));
    
        if setpoint>100 || setpoint<2
      uiwait(errordlg('SetPoint Can Be Between 2 and 100 CM . '));
      return
        end
    
    
    % if we are in compare mode the graph should be hold on
    % but if we aren`t it should be cleared:
      if str2double(get(handles.flag_for_compare_mode,'string'))==1
      hold(handles.axes1,'on')
      hold(handles.axes10,'on')
      end
      if str2double(get(handles.flag_for_compare_mode,'string'))==0
      hold(handles.axes1,'off')
      hold(handles.axes10,'off')
       cla(handles.axes1,'reset')
      cla(handles.axes10,'reset')
      end
     
     % reading current inlet:
     initial_inlet=str2double(get(handles.inlet_flowrate_static,'string'));
     % reading controll gain and reset time:
     controllergain=str2double(get(handles.controller_gain_edit,'string')); 
     resettime=str2double(get(handles.reset_or_derive_time_edit,'string')); 

     
       % previous levels for comparing with current ones for pictures:
        previous_main_tank_level=0;
        previous_upper_tank_level=0;
        
        
        
        
        % if it is not the first time we click on simulate , so we have
    % y_memory form previous simulation :
    if str2double(get(handles.simulation_counter,'string'))~=0 
       hold(handles.axes1,'on')
       time_for_history_draw=[start_simulation_time:sample_rate:0];
        plot(handles.axes1,time_for_history_draw,[y_memory((length(y_memory)-length(time_for_history_draw)+1):length(y_memory))],'b.:','markersize',5)
        axis(handles.axes1,[start_simulation_time end_simulation_time real(min(y(:,2)))-10 real(max(y(:,2)))+10])
        hold(handles.axes10,'on')
        
      
        if str2double(get(handles.contoller_output_counter,'string'))~=0
        plot(handles.axes10,time_for_history_draw,[controller_output_memory((length(controller_output_memory)-length(time_for_history_draw)+1):length(controller_output_memory))],'b.:','markersize',5)
        plot(handles.axes1,[start_simulation_time 0],[setpoint_memory setpoint_memory],'m')
         plot(handles.axes1,[0 0],[setpoint_memory setpoint],'m')
%         plot(handles.axes10,[0 0],[inlet_setpoint_memory inlet])
        end
        if str2double(get(handles.contoller_output_counter,'string'))==0
        plot(handles.axes10,time_for_history_draw,[linspace(inlet_setpoint_memory,inlet_setpoint_memory,length(time_for_history_draw))])
%         plot(handles.axes10,[0 0],[inlet_setpoint_memory inlet])
        end
        
        axis(handles.axes10,[start_simulation_time end_simulation_time 1 27])
%         plot(handles.axes10,[t(1) t(length(t))],[inlet inlet]);
    end
    % but if it is the first time we simulate , it should draw for level 49
    % and inlet 20
    level_main_tank=str2double(get(handles.level_static,'string'));
    inlet_for_first_simulate=str2double(get(handles.inlet_flowrate_static,'string'));
    if str2double(get(handles.simulation_counter,'string'))==0 
        hold(handles.axes1,'on')
        
        time_for_history_draw=[start_simulation_time:sample_rate:0];
        plot(handles.axes1,time_for_history_draw,[linspace( level_main_tank, level_main_tank,length(time_for_history_draw))],'b.:','markersize',5)
        axis(handles.axes1,[start_simulation_time end_simulation_time real(min(y(:,2)))-10 real(max(y(:,2)))+10])
        hold(handles.axes10,'on')
        plot(handles.axes10,time_for_history_draw,[linspace(inlet_for_first_simulate,inlet_for_first_simulate,length(time_for_history_draw))])
        plot(handles.axes10,[0 0],[inlet_for_first_simulate inlet])
        axis(handles.axes10,[start_simulation_time end_simulation_time 1 27])
        plot(handles.axes10,[t(1) t(length(t))],[inlet inlet]);
    end
    
     
    inlet_store=[]; 
        
        

  for i=1:length(t_sim)
      
        if i>abs(start_simulation_time/sample_rate)
%         set(handles.stop_pushbutton,'visible','on');
        end
        
 axis(handles.axes1,[start_simulation_time end_simulation_time -1 100])
 axis(handles.axes10,[start_simulation_time end_simulation_time 1 27])
 % I concepts:
 error=error+setpoint-real(y(2,2));
 inlet=initial_inlet+ (sample_rate*controllergain/resettime)*error;
inlet_store=[inlet_store inlet]; 
% inlet can`t be less than zero,but zero inlet makes the ODE too slow!
% so we let it be 1 !
    if inlet<0
    inlet=1;
    end
      if inlet>25
    inlet=25;
      end
        
         % writing inlet static:  
        set(handles.inlet_flowrate_static,'string',sprintf('%0.2f',inlet));

        tspan=[t_sim(i) t_sim(i)+sample_rate t_sim(i)+2*sample_rate];

        % solving:
          % it seems that ode23 is the fastest in ODE`s..
         [t,y]=ode23(@myfun2,tspan,[y(2,1) y(2,2)]);

        Y=[Y real(y(2,2))];
    
        % full tank check:
        if y(2,1)>100
            y(2,1)=100;
            set(handles.upper_tank_full,'visible','on');
             pause(0.05)
            set(handles.upper_tank_full,'visible','off')
        end
        
        %empty tank check:
        % main tank:
        if real(y(2,2))<3
            y(2,2)=3;
        end
        % upper tank:
        if real(y(2,1))<3
            y(2,1)=3;
        end
        
        % alarms:
        if real(y(2,2))>high_level_alarm
            set(handles.high_alarm,'visible','on')
            pause(0.03)
            set(handles.high_alarm,'visible','off')
        end

        if real(y(2,2))<low_level_alarm
            set(handles.low_alarm,'visible','on')
            pause(0.03)
            set(handles.low_alarm,'visible','off')
        end
      
 % making the name for picture and set it to axes :
% to make the program faster we compare previous level with current one:
%main tank:
if floor(real(y(2,2)))~= previous_main_tank_level
picname=strcat('tank',num2str(floor(real(y(2,2)))),'.jpg');
axes(handles.axes6);
imread(picname);
imshow(picname);
pause(0.00001)
end
 previous_main_tank_level=floor(real(y(2,2)));
 % upper tank:
if floor(real(y(2,1)))~=previous_upper_tank_level
picname=strcat('tanku',num2str(floor(real(y(2,1)))),'.jpg');
axes(handles.axes8);
imread(picname);
imshow(picname);
pause(0.00001)
end  
previous_upper_tank_level=floor(real(y(2,1)));


        
        % writing levels and outlet:
            set(handles.level_static,'string',sprintf('%0.2f',real(y(2,2))))
            set(handles.level_static_upper_tank,'string',sprintf('%0.2f',real(y(2,1))))
            set(handles.outlet_flowrate,'string',sprintf('%0.2f',inlet-dis))
            
            % slider:
            % it seems when i=1 we get a (0,0) in plot! i don`t know why!!
            if i~=1
            set(handles.slider3,'value',Y(i)/100)
            end
            
            
        % ploting:
          plot(handles.axes1,t_sim(i),Y(i),'b.:','markersize',5)
          hold(handles.axes1,'on')
          if i==1
       plot(handles.axes1,[0 end_simulation_time],[setpoint setpoint],'m');
          end
          plot(handles.axes10,t_sim(i),inlet,'b.:','markersize',5)
          hold(handles.axes10,'on')
         %writing time static
          set(handles.time_static,'string',sprintf('%0.2f',t_sim(i)));
    

          % stop check:
                if  str2double(get(handles.stop_pushbutton_hidden,'string'))==1;
                    set(handles.stop_pushbutton,'visible','off');
                    % if we are not in compare mode levels should be
                    % updatetd after stop button pressed but not for
                    % otherwise:
                        if str2double(get(handles.flag_for_compare_mode,'string'))==0
                           set(handles.upper_tank_initial_level_hidden,'string',y(size(y,1),1))
                           set(handles.main_tank_initial_level_hidden,'string',y(size(y,1),2))
                        end

                    return
                end
                
      pause(0.000001)
  end
    
    %inital level update for next simulation
      % it means we are not in compare mode and we should update initial
  % values:
  if str2double(get(handles.flag_for_compare_mode,'string'))==0
    % write initial values for next use when we are not in compare mode: 
          set(handles.upper_tank_initial_level_hidden,'string',y(size(y,1),1))
          set(handles.main_tank_initial_level_hidden,'string',y(size(y,1),2))
  end
    
    
    
     % invisblize stop button: 
    set(handles.stop_pushbutton,'visible','off');
    y_memory=Y;
    inlet_setpoint_memory=setpoint;
    controller_output_memory=inlet_store;
    setpoint_memory=setpoint;
    
    % now we want to know how many times we have had controller output ( the number of times we had closed loop ! :
    contoller_output_counter=str2double(get(handles.contoller_output_counter,'string'));
    contoller_output_counter=contoller_output_counter+1;
    set(handles.contoller_output_counter,'string',contoller_output_counter);
    
    
end











% PI :


if get(handles.cntr_menu,'value')==4
    error=0;
    % initial values: 
         upper_tank_initial_level=str2double(get(handles.upper_tank_initial_level_hidden,'string'));
         main_tank_initial_level=str2double(get(handles.main_tank_initial_level_hidden,'string'));
% slider initial value:
         set(handles.slider3,'value',main_tank_initial_level/100)
% stop button:

    
    
    t_sim=0:sample_rate:end_simulation_time;

    
       y=[0 0;upper_tank_initial_level main_tank_initial_level];
       Y=0;

    % reading setpoint:
    setpoint=str2double(get(handles.set_point_edit,'string'));
    
           if setpoint>100 || setpoint<2
      uiwait(errordlg('SetPoint Can Be Between 2 and 100 CM . '));
      return
           end
    
         
    % if we are in compare mode the graph should be hold on
    % but if we aren`t it should be cleared:
      if str2double(get(handles.flag_for_compare_mode,'string'))==1
      hold(handles.axes1,'on')
      hold(handles.axes10,'on')
      end
      if str2double(get(handles.flag_for_compare_mode,'string'))==0
      hold(handles.axes1,'off')
      hold(handles.axes10,'off')
      cla(handles.axes1,'reset')
      cla(handles.axes10,'reset')
      end
     
     % reading current inlet:
     initial_inlet=str2double(get(handles.inlet_flowrate_static,'string'));
     % reading controll gain and reset time:
     controllergain=str2double(get(handles.controller_gain_edit,'string')); 
     resettime=str2double(get(handles.reset_or_derive_time_edit,'string')); 
     
     
       % previous levels for comparing with current ones for pictures:
        previous_main_tank_level=0;
        previous_upper_tank_level=0;
        

        % if it is not the first time we click on simulate , so we have
    % y_memory form previous simulation :
    if str2double(get(handles.simulation_counter,'string'))~=0 
       hold(handles.axes1,'on')
       time_for_history_draw=[start_simulation_time:sample_rate:0];
        plot(handles.axes1,time_for_history_draw,[y_memory((length(y_memory)-length(time_for_history_draw)+1):length(y_memory))],'b.:','markersize',5)
        axis(handles.axes1,[start_simulation_time end_simulation_time real(min(y(:,2)))-10 real(max(y(:,2)))+10])
        hold(handles.axes10,'on')
        
      
        if str2double(get(handles.contoller_output_counter,'string'))~=0
        plot(handles.axes10,time_for_history_draw,[controller_output_memory((length(controller_output_memory)-length(time_for_history_draw)+1):length(controller_output_memory))],'b.:','markersize',5)
        plot(handles.axes1,[start_simulation_time 0],[setpoint_memory setpoint_memory],'m')
         plot(handles.axes1,[0 0],[setpoint_memory setpoint],'m')
%         plot(handles.axes10,[0 0],[inlet_setpoint_memory inlet])
        end
        if str2double(get(handles.contoller_output_counter,'string'))==0
        plot(handles.axes10,time_for_history_draw,[linspace(inlet_setpoint_memory,inlet_setpoint_memory,length(time_for_history_draw))])
%         plot(handles.axes10,[0 0],[inlet_setpoint_memory inlet])
        end
        
        axis(handles.axes10,[start_simulation_time end_simulation_time 1 27])
%         plot(handles.axes10,[t(1) t(length(t))],[inlet inlet]);
    end
    % but if it is the first time we simulate , it should draw for level 49
    % and inlet 20

    level_main_tank=str2double(get(handles.level_static,'string'));
    inlet_for_first_simulate=str2double(get(handles.inlet_flowrate_static,'string'));
    if str2double(get(handles.simulation_counter,'string'))==0 
        hold(handles.axes1,'on')
        
        time_for_history_draw=[start_simulation_time:sample_rate:0];
        plot(handles.axes1,time_for_history_draw,[linspace( level_main_tank, level_main_tank,length(time_for_history_draw))],'b.:','markersize',5)
        axis(handles.axes1,[start_simulation_time end_simulation_time real(min(y(:,2)))-10 real(max(y(:,2)))+10])
        hold(handles.axes10,'on')
        plot(handles.axes10,time_for_history_draw,[linspace(inlet_for_first_simulate,inlet_for_first_simulate,length(time_for_history_draw))])
        plot(handles.axes10,[0 0],[inlet_for_first_simulate inlet])
        axis(handles.axes10,[start_simulation_time end_simulation_time 1 27])
        plot(handles.axes10,[t(1) t(length(t))],[inlet inlet]);
    end
    
    


        inlet_store=[];
  for i=1:length(t_sim)
        
        if i>abs(start_simulation_time/sample_rate)
%         set(handles.stop_pushbutton,'visible','on');
        end
      
 axis(handles.axes1,[start_simulation_time end_simulation_time -1 100])
 axis(handles.axes10,[start_simulation_time end_simulation_time 1 27])
 % PI concepts:
currenterror=setpoint-real(y(2,2));
error=error+setpoint-real(y(2,2));
inlet= controllergain*currenterror+initial_inlet+ (sample_rate*controllergain/resettime)*error;
inlet_store=[inlet_store inlet];

% inlet can`t be less than zero,but zero inlet makes the ODE too slow!
% so we let it be 1 !
    if inlet<0
    inlet=1;
    end
         if inlet>25
    inlet=25;
         end
        
         % writing inlet static:  
        set(handles.inlet_flowrate_static,'string',sprintf('%0.2f',inlet));

        tspan=[t_sim(i) t_sim(i)+sample_rate t_sim(i)+2*sample_rate];

        % solving:
          % it seems that ode23 is the fastest in ODE`s..
         [t,y]=ode23(@myfun2,tspan,[y(2,1) y(2,2)]);

        Y=[Y real(y(2,2))];
    
        % full tank check:
        if y(2,1)>100
            y(2,1)=100;
            set(handles.upper_tank_full,'visible','on');
             pause(0.05)
            set(handles.upper_tank_full,'visible','off')
        end
        
        %empty tank check:
        % main tank:
        if real(y(2,2))<3
            y(2,2)=3;
        end
        % upper tank:
        if real(y(2,1))<3
            y(2,1)=3;
        end
        
        % alarms:
        if real(y(2,2))>high_level_alarm 
            set(handles.high_alarm,'visible','on')
            pause(0.03)
            set(handles.high_alarm,'visible','off')
        end

        if real(y(2,2))<low_level_alarm
            set(handles.low_alarm,'visible','on')
            pause(0.03)
            set(handles.low_alarm,'visible','off')
        end
      
        
        % making the name for picture and set it to axes :
        % to make the program faster we compare previous level with current one:
        %main tank:
        if floor(real(y(2,2)))~= previous_main_tank_level
         picname=strcat('tank',num2str(floor(real(y(2,2)))),'.jpg');
         axes(handles.axes6);
         imread(picname);
         imshow(picname);
         pause(0.00001)
        end
        previous_main_tank_level=floor(real(y(2,2)));
        % upper tank:
        if floor(real(y(2,1)))~=previous_upper_tank_level
        picname=strcat('tanku',num2str(floor(real(y(2,1)))),'.jpg');
        axes(handles.axes8);
        imread(picname);
        imshow(picname);
        pause(0.00001)
        end  
        previous_upper_tank_level=floor(real(y(2,1)));

        
        % writing levels and outlet:
            set(handles.level_static,'string',sprintf('%0.2f',real(y(2,2))))
            set(handles.level_static_upper_tank,'string',sprintf('%0.2f',real(y(2,1))))
            set(handles.outlet_flowrate,'string',sprintf('%0.2f',inlet-dis))
            
            % slider:
            % it seems when i=1 we get a (0,0) in plot! i don`t know why!!
            if i~=1
            set(handles.slider3,'value',Y(i)/100)
            end
            
            
        % ploting:
          plot(handles.axes1,t_sim(i),Y(i),'b.:','markersize',5)
          hold(handles.axes1,'on')
          plot(handles.axes10,t_sim(i),inlet,'b.:','markersize',5)
          if i==1
       plot(handles.axes1,[0 end_simulation_time],[setpoint setpoint],'m');
          end
          hold(handles.axes10,'on')
         %writing time static
          set(handles.time_static,'string',sprintf('%0.2f',t_sim(i)));
    
            % stop check:
                if  str2double(get(handles.stop_pushbutton_hidden,'string'))==1;
                    set(handles.stop_pushbutton,'visible','off');
                    % if we are not in compare mode levels should be
                    % updatetd after stop button pressed but not for
                    % otherwise:
                        if str2double(get(handles.flag_for_compare_mode,'string'))==0
                           set(handles.upper_tank_initial_level_hidden,'string',y(size(y,1),1))
                           set(handles.main_tank_initial_level_hidden,'string',y(size(y,1),2))
                        end

                    return
                end
                
      pause(0.000001)
  end
    
    %inital level update for next simulation
   % it means we are not in compare mode and we should update initial
  % values:
  if str2double(get(handles.flag_for_compare_mode,'string'))==0
    % write initial values for next use when we are not in compare mode: 
          set(handles.upper_tank_initial_level_hidden,'string',y(size(y,1),1))
          set(handles.main_tank_initial_level_hidden,'string',y(size(y,1),2))
  end
    
    % invisblize stop button: 
    set(handles.stop_pushbutton,'visible','off');
    y_memory=Y;
    inlet_setpoint_memory=setpoint;
    controller_output_memory=inlet_store;
    setpoint_memory=setpoint;
    
    % now we want to know how many times we have had controller output ( the number of times we had closed loop ! :
    contoller_output_counter=str2double(get(handles.contoller_output_counter,'string'));
    contoller_output_counter=contoller_output_counter+1;
    set(handles.contoller_output_counter,'string',contoller_output_counter);
    
end












% PID ( D on error ) 



if get(handles.cntr_menu,'value')==5
    error=0;
    % initial values: 
         upper_tank_initial_level=str2double(get(handles.upper_tank_initial_level_hidden,'string'));
main_tank_initial_level=str2double(get(handles.main_tank_initial_level_hidden,'string'));
% slider initial value:
set(handles.slider3,'value',main_tank_initial_level/100)
% stop button:
%     set(handles.stop_pushbutton,'visible','on');
%     
    t_sim=0:sample_rate:end_simulation_time;

    
       y=[0 0;upper_tank_initial_level main_tank_initial_level];
    Y=0;

    % reading setpoint:
    setpoint=str2double(get(handles.set_point_edit,'string'));
    
           if setpoint>100 || setpoint<2
      uiwait(errordlg('SetPoint Can Be Between 2 and 100 CM . '));
      return
           end
    
          % previous levels for comparing with current ones for pictures:
        previous_main_tank_level=0;
        previous_upper_tank_level=0;
    
         
    % if we are in compare mode the graph should be hold on
    % but if we aren`t it should be cleared:
      if str2double(get(handles.flag_for_compare_mode,'string'))==1
      hold(handles.axes1,'on')
      hold(handles.axes10,'on')
      end
      if str2double(get(handles.flag_for_compare_mode,'string'))==0
      hold(handles.axes1,'off')
      hold(handles.axes10,'off')
      cla(handles.axes1,'reset')
      cla(handles.axes10,'reset')
      end
     
     % reading current inlet:
     initial_inlet=str2double(get(handles.inlet_flowrate_static,'string'));
     % reading controll gain and reset time:
     controllergain=str2double(get(handles.controller_gain_edit,'string')); 
     resettime=str2double(get(handles.reset_or_derive_time_edit,'string'));
     derivetime=str2double(get(handles.derive_time_edit,'string'));
     previouserror=setpoint-real(y(2,2));
     
        % if it is not the first time we click on simulate , so we have
    % y_memory form previous simulation :
    if str2double(get(handles.simulation_counter,'string'))~=0 
       hold(handles.axes1,'on')
       time_for_history_draw=[start_simulation_time:sample_rate:0];
        plot(handles.axes1,time_for_history_draw,[y_memory((length(y_memory)-length(time_for_history_draw)+1):length(y_memory))],'b.:','markersize',5)
        axis(handles.axes1,[start_simulation_time end_simulation_time real(min(y(:,2)))-10 real(max(y(:,2)))+10])
        hold(handles.axes10,'on')
        
      
        if str2double(get(handles.contoller_output_counter,'string'))~=0
        plot(handles.axes10,time_for_history_draw,[controller_output_memory((length(controller_output_memory)-length(time_for_history_draw)+1):length(controller_output_memory))],'b.:','markersize',5)
        plot(handles.axes1,[start_simulation_time 0],[setpoint_memory setpoint_memory],'m')
         plot(handles.axes1,[0 0],[setpoint_memory setpoint],'m')
%         plot(handles.axes10,[0 0],[inlet_setpoint_memory inlet])
        end
        if str2double(get(handles.contoller_output_counter,'string'))==0
        plot(handles.axes10,time_for_history_draw,[linspace(inlet_setpoint_memory,inlet_setpoint_memory,length(time_for_history_draw))])
%         plot(handles.axes10,[0 0],[inlet_setpoint_memory inlet])
        end
        
        axis(handles.axes10,[start_simulation_time end_simulation_time 1 27])
%         plot(handles.axes10,[t(1) t(length(t))],[inlet inlet]);
    end
    % but if it is the first time we simulate , it should draw for level 49
    % and inlet 20
    level_main_tank=str2double(get(handles.level_static,'string'));
    inlet_for_first_simulate=str2double(get(handles.inlet_flowrate_static,'string'));
    if str2double(get(handles.simulation_counter,'string'))==0 
        hold(handles.axes1,'on')
        
        time_for_history_draw=[start_simulation_time:sample_rate:0];
        plot(handles.axes1,time_for_history_draw,[linspace( level_main_tank, level_main_tank,length(time_for_history_draw))],'b.:','markersize',5)
        axis(handles.axes1,[start_simulation_time end_simulation_time real(min(y(:,2)))-10 real(max(y(:,2)))+10])
        hold(handles.axes10,'on')
        plot(handles.axes10,time_for_history_draw,[linspace(inlet_for_first_simulate,inlet_for_first_simulate,length(time_for_history_draw))])
        plot(handles.axes10,[0 0],[inlet_for_first_simulate inlet])
        axis(handles.axes10,[start_simulation_time end_simulation_time 1 27])
        plot(handles.axes10,[t(1) t(length(t))],[inlet inlet]);
    end
    
    
        inlet_store=[];
     

     
  for i=1:length(t_sim)
        
 axis(handles.axes1,[start_simulation_time end_simulation_time -1 100])
 axis(handles.axes10,[start_simulation_time end_simulation_time 1 27])
 
        if i>abs(start_simulation_time/sample_rate)
%         set(handles.stop_pushbutton,'visible','on');
        end

 % PID concepts:
currenterror=setpoint-real(y(2,2));

error=error+setpoint-real(y(2,2));
% if i==1;
inlet= controllergain*currenterror+initial_inlet+ sample_rate*(controllergain/resettime)*error+(controllergain*derivetime/sample_rate)*(currenterror-previouserror);
% inlet= controllergain*currenterror+ (controllergain/resettime)*error+(controllergain*derivetime)*(currenterror-previouserror);
% end
% if i~=1
%      inlet= controllergain*currenterror+ sample_rate*(controllergain/resettime)*error+(controllergain*derivetime/sample_rate)*(currenterror-previouserror)+inlet;
% end
previouserror=currenterror;
inlet_store=[inlet_store inlet];
% inlet can`t be less than zero,but zero inlet makes the ODE too slow!
% so we let it be 1 !
    if inlet<0
    inlet=1;
    end
        if inlet>25
    inlet=25;
        end
         % writing inlet static:  
        set(handles.inlet_flowrate_static,'string',sprintf('%0.2f',inlet));

        tspan=[t_sim(i) t_sim(i)+sample_rate t_sim(i)+2*sample_rate];

        % solving:
          % it seems that ode23 is the fastest in ODE`s..
         [t,y]=ode23(@myfun2,tspan,[y(2,1) y(2,2)]);

        Y=[Y real(y(2,2))];
    
        % full tank check:
        if y(2,1)>100
            y(2,1)=100;
            set(handles.upper_tank_full,'visible','on');
             pause(0.05)
            set(handles.upper_tank_full,'visible','off')
        end
        
        %empty tank check:
        % main tank:
        if real(y(2,2))<3
            y(2,2)=3;
        end
        % upper tank:
        if real(y(2,1))<3
            y(2,1)=3;
        end
        
        % alarms:
        if real(y(2,2))>high_level_alarm 
            set(handles.high_alarm,'visible','on')
            pause(0.03)
            set(handles.high_alarm,'visible','off')
        end

        if real(y(2,2))<low_level_alarm
            set(handles.low_alarm,'visible','on')
            pause(0.03)
            set(handles.low_alarm,'visible','off')
        end
      
        
         % making the name for picture and set it to axes :
        % to make the program faster we compare previous level with current one:
        %main tank:
        if floor(real(y(2,2)))~= previous_main_tank_level
         picname=strcat('tank',num2str(floor(real(y(2,2)))),'.jpg');
         axes(handles.axes6);
         imread(picname);
         imshow(picname);
         pause(0.00001)
        end
        previous_main_tank_level=floor(real(y(2,2)));
        % upper tank:
        if floor(real(y(2,1)))~=previous_upper_tank_level
        picname=strcat('tanku',num2str(floor(real(y(2,1)))),'.jpg');
        axes(handles.axes8);
        imread(picname);
        imshow(picname);
        pause(0.00001)
        end  
        previous_upper_tank_level=floor(real(y(2,1)));
        
        % writing levels and outlet:
            set(handles.level_static,'string',sprintf('%0.2f',real(y(2,2))))
            set(handles.level_static_upper_tank,'string',sprintf('%0.2f',real(y(2,1))))
            set(handles.outlet_flowrate,'string',sprintf('%0.2f',inlet-dis))
            
            % slider:
            % it seems when i=1 we get a (0,0) in plot! i don`t know why!!
            if i~=1
            set(handles.slider3,'value',Y(i)/100)
            end
            
            
        % ploting:
          plot(handles.axes1,t_sim(i),Y(i),'b.:','markersize',5)
          hold(handles.axes1,'on')
          if i==1
       plot(handles.axes1,[0 end_simulation_time],[setpoint setpoint],'m');
          end
          plot(handles.axes10,t_sim(i),inlet,'b.:','markersize',5)
          hold(handles.axes10,'on')
          
         %writing time static
          set(handles.time_static,'string',sprintf('%0.2f',t_sim(i)));
    
            % stop check:
                if  str2double(get(handles.stop_pushbutton_hidden,'string'))==1;
                    set(handles.stop_pushbutton,'visible','off');
                    % if we are not in compare mode levels should be
                    % updatetd after stop button pressed but not for
                    % otherwise:
                        if str2double(get(handles.flag_for_compare_mode,'string'))==0
                           set(handles.upper_tank_initial_level_hidden,'string',y(size(y,1),1))
                           set(handles.main_tank_initial_level_hidden,'string',y(size(y,1),2))
                        end

                    return
                end
                
      pause(0.000001)
  end
    
    %inital level update for next simulation
      % it means we are not in compare mode and we should update initial
  % values:
  if str2double(get(handles.flag_for_compare_mode,'string'))==0
    % write initial values for next use when we are not in compare mode: 
          set(handles.upper_tank_initial_level_hidden,'string',y(size(y,1),1))
          set(handles.main_tank_initial_level_hidden,'string',y(size(y,1),2))
  end
    
    
     % invisblize stop button: 
    set(handles.stop_pushbutton,'visible','off');
    y_memory=Y;
    inlet_setpoint_memory=setpoint;
    controller_output_memory=inlet_store;
    setpoint_memory=setpoint;
    
    % now we want to know how many times we have had controller output ( the number of times we had closed loop ! :
    contoller_output_counter=str2double(get(handles.contoller_output_counter,'string'));
    contoller_output_counter=contoller_output_counter+1;
    set(handles.contoller_output_counter,'string',contoller_output_counter);
    
    
end

% now we want to know how many times we have simulated ! :
simulation_counter=str2double(get(handles.simulation_counter,'string'));
simulation_counter=simulation_counter+1;
 set(handles.simulation_counter,'string',simulation_counter);
 
 a=get(handles.grid_on,'checked');
 switch a
     case 'on'
         set(handles.axes1,'ygrid','on')
         set(handles.axes1,'xgrid','on')
         
         set(handles.axes10,'ygrid','on')
         set(handles.axes10,'xgrid','on')
         
        
     case 'off'
         set(handles.axes1,'ygrid','off')
         set(handles.axes1,'xgrid','off')
         
         set(handles.axes10,'ygrid','off')
         set(handles.axes10,'xgrid','off')
 end
 
% set(handles.grid_off,'checked','on')


function dh=myfun(t,h)
global inlet
global dis
dh=[10;10];


dh(1)=(-2.5*(h(1))^(0.5)+inlet)/10;
dh(2)=(2.5*h(1)^(0.5)-2.5*(h(2))^(0.5)-dis)/10;

function dh=myfun2(t,h)
global inlet
global dis
global y
 dh=[real(y(1,1)); real(y(1,2))];


dh(1)=(-2.5*(h(1))^(0.5)+inlet)/10;
dh(2)=(2.5*h(1)^(0.5)-2.5*(h(2))^(0.5)-dis)/10;

% --- Executes during object creation, after setting all properties.
% function pictureshow(q)
% hold(handles.axes3,'off')
% if 20<q<30
%     imshow('tank90.tif')
% end
% if 30<q<40
%     imshow('tank92.tif')
% end
% if 40<q<50
%     imshow('tank94.tif')
% end
% if 50<q<60
%     imshow('tank96.tif')
% end

 

% --------------------------------------------------------------------
function Untitled_1_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function Untitled_2_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function sample_time_Callback(hObject, eventdata, handles)
% hObject    handle to sample_time (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function end_s_time_Callback(hObject, eventdata, handles)
% hObject    handle to end_s_time (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function sample_interval_Callback(hObject, eventdata, handles)
% hObject    handle to sample_interval (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function time_options_Callback(hObject, eventdata, handles)
% hObject    handle to time_options (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

  prompt={'Start simulation Time (sec) : ',' End simulation Time (sec) : ','Sample rate (sec) :','Pause Time between each sample (sec) : '};
   name=' Time Options: ';
   numlines=1;
     defaultanswer={get(handles.start_simulation_hidden,'string'),get(handles.end_time_hidden,'string'),get(handles.sample_rate_hidden,'string'),get(handles.pause_time_hidden,'string')};

   answer=inputdlg(prompt,name,numlines,defaultanswer);
   if size(answer)==[0 0]
       return
   end

   % Im going to write these variables in 3 hidden texts , so that I can
   % call the in any functions!!
   start_time=str2double(answer{1});
    set(handles.start_simulation_hidden,'string',start_time)
   end_simulation_time=str2double(answer{2});
   set(handles.end_time_hidden,'string',end_simulation_time)
  sample_rate=str2double(answer{3});
  if sample_rate>12
      
      % uiwait :
      % UIWAIT(FIG) blocks execution until either UIRESUME is called or the
   % figure FIG is destroyed (closed)
      uiwait(errordlg('Sample Rate Can`t Be Greater Than 12sec. Because Of Accuracy Drop. '));
set(handles.sample_rate_hidden,'string',12)
time_options_Callback(hObject, eventdata, handles)
  end
    if abs(start_time)>abs(end_simulation_time)
      
      % uiwait :
      % UIWAIT(FIG) blocks execution until either UIRESUME is called or the
   % figure FIG is destroyed (closed)
      uiwait(errordlg('Absolute Of Start Simulation, Should Be A Time, Less than End Simulation '));
time_options_Callback(hObject, eventdata, handles)
    end
   if start_time>0
      
      % uiwait :
      % UIWAIT(FIG) blocks execution until either UIRESUME is called or the
   % figure FIG is destroyed (closed)
      uiwait(errordlg('The Maximum Time Allowed For Start Simulation Is 0 ! '));
time_options_Callback(hObject, eventdata, handles)
   end
  set(handles.sample_rate_hidden,'string',sample_rate)
  pause_time=str2double(answer{4});
  set(handles.pause_time_hidden,'string',pause_time)
  guidata(hObject, handles);


% --------------------------------------------------------------------
function save_data_file_Callback(hObject, eventdata, handles)
% hObject    handle to save_data_file (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global y Y
global t t_sim
global inlet

T=t;
% setpoint=inlet;


prompt={'Enter The File Name: '};
name='File Name';
answer=inputdlg(prompt,name);

if size(answer)==[0 0]
    return
end
format='.txt';
filename=strcat(answer,format);





directoryName = uigetdir('','Please select the folder to save Data :'); 
if directoryName==0
    return
end


 fid = fopen(filename{1},'w');

 if get(handles.cntr_menu,'value')==1
     OutPut=y(:,2);
inlett=linspace(inlet,inlet,length(T));
inlett=transpose(inlett);

fprintf(fid,' OutPut: \n');
fprintf(fid,' \n')
fprintf(fid,' number    Input     Time      OutPut  \n');

     for j=1:length(OutPut)
fprintf(fid,'%6.0f     %5.2f     %5.1f     %5.4f \n',j,inlett(j),T(j),OutPut(j));
     end
 end
 
  if get(handles.cntr_menu,'value')~=1
      OutPut=Y(2:end);
      setpoint=str2double(get(handles.set_point_edit,'string'));
setpointt=linspace(setpoint,setpoint,length(t_sim));
setpointt=transpose(setpointt);

fprintf(fid,' OutPut: \n');
fprintf(fid,' \n')
fprintf(fid,' number   SetPoint    Time     OutPut  \n');

     for j=1:length(OutPut)
fprintf(fid,'%6.0f     %5.2f     %5.1f     %5.4f \n',j,setpointt(j),t_sim(j),OutPut(j));
     end
 end
 
copyfile(filename{1},directoryName)



function set_point_edit_Callback(hObject, eventdata, handles)
% hObject    handle to set_point_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of set_point_edit as text
%        str2double(get(hObject,'String')) returns contents of set_point_edit as a double


% --- Executes during object creation, after setting all properties.
function set_point_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to set_point_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function controller_gain_edit_Callback(hObject, eventdata, handles)
% hObject    handle to controller_gain_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of controller_gain_edit as text
%        str2double(get(hObject,'String')) returns contents of controller_gain_edit as a double


% --- Executes during object creation, after setting all properties.
function controller_gain_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to controller_gain_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in stop_pushbutton.
function stop_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to stop_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)





% 1 means stop!
%  set(handles.stop_pushbutton_hidden,'string',1)


% --- Executes during object creation, after setting all properties.
function amir_CreateFcn(hObject, eventdata, handles)
% hObject    handle to axes2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: place code in OpeningFcn to populate axes2


% --- Executes during object creation, after setting all properties.
function axes3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to axes3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: place code in OpeningFcn to populate axes3
%   imshow('tank.tif')


% --------------------------------------------------------------------
function fit_model_Callback(hObject, eventdata, handles)
% hObject    handle to fit_model (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function first_order_Callback(hObject, eventdata, handles)
% hObject    handle to first_order (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global y_for_model

global tow_for_tunning_parameters
global k_for_tunning_parameters

% if str2double(get(handles.flag_for_no_y_used_for_error,'string'))==0;
%     %0 means the user has choose fit model while there is no y!
%     errordlg(' There is no output to fit model ! ')
%     return
% end


if str2double(get(handles.pulse_test_flag,'string'))==0;
    errordlg(' To Fit A Model You Should First Collect Data From Pulse Test Menu ')
    return
end


global y
global t
global step_difference_for_modeling
global sample_rate
global model duration_time






% y2=real(y(:,2));
% y2 : main tank
sample_rate=str2double(get(handles.sample_rate_hidden,'string'));
u=linspace(step_difference_for_modeling,step_difference_for_modeling,length( y_for_model));
u=transpose(u);
% iddata makes y and u and sample interval into a variabe suitable for
% n4sid

z=iddata( y_for_model,u,sample_rate);

%z estimate a model with order 1 (in this case) from iddata
% !!! (see also n4sid)
% n4sid: model is in state space , so we convert it to tf first, and convert it to
% continues time ( d2c : discrete to continues


   prompt={'Minimum Guess For Time constant (sec) : ','Maximum Guess For Time constant (sec) : '};
   name=' Parameters Limit: ';
   numlines=1;
% reading default answers from 2 hidden texts:
  defaultanswer={get(handles.Tp1_min_guess_hidden,'string'),get(handles.Tp1_max_guess_hidden,'string')};
     
     
   answer=inputdlg(prompt,name,numlines,defaultanswer,'on');
   if size(answer)==[0 0]
       return
   end
   
   if str2double(answer{2}) <= str2double(answer{1})
       % uiwait :
       % UIWAIT(FIG) blocks execution until either UIRESUME is called or
       % th
       uiwait( errordlg(' Maximum Guess Should Be Greater Than Minimum Guess ' ))
       first_order_Callback(hObject, eventdata, handles)
       return
   end
   
    % I`m going to write new inputs in 2 hidden static text to be saved for
    % next use:
   set(handles.Tp1_min_guess_hidden,'string',str2double(answer{1}))
   set(handles.Tp1_max_guess_hidden,'string',str2double(answer{2}))
   
   
   
   % processing sometimes take too much time, so we design a waiting alarm
% with red color
% we set everything invisible , so that in second or more tries we don`t
% see parameters from previous tests:
set(handles.text23,'string', ' Waiting . . . ');
set(handles.text23,'foregroundColor',[1 0 0]);
set(handles.text23,'visible', ' on');
set(handles.text24,'visible' , 'off' );
set(handles.text25,'visible' , 'off' );
set(handles.K,'visible' , 'off' );
set(handles.T,'visible' , 'off' );
set(handles.text27,'visible' , 'off' );
set(handles.text29,'visible' , 'off' );
set(handles.text52,'visible' , 'off' );
set(handles.text54,'visible' , 'off' );
set(handles.text58,'visible' , 'off' );
set(handles.text61,'visible' , 'off' );
set(handles.deadtime_static,'visible' , 'off' );
set(handles.second_time_constant_static,'visible' , 'off' ); 


model=pem(z,'P1','Tp1',{'max',str2double(answer{2})},'Tp1',{'min',str2double(answer{1})});
% p1 means polonomyal first order

 % type get(model) to see what a contains and what we are going to do:!
 
 k=model.kp.value;
 tow=model.Tp1.value
 
 k2=( y_for_model(length(y_for_model))- y_for_model(1))/step_difference_for_modeling;
 
  % 2 floating point needed:
 tow=sprintf('%0.2f',tow);
 k=sprintf('%0.2f',k);
 k2=sprintf('%0.2f',k2);
 
set(handles.text23,'string', ' First Order Parameters : ');
set(handles.text23,'foregroundColor',[0 0 0]);
% back to black!
set(handles.text23,'visible' , 'on' );
set(handles.text24,'visible' , 'on' );
set(handles.text25,'visible' , 'on' );
set(handles.K,'string' ,k2);
set(handles.K,'visible' , 'on' );
set(handles.T,'string' ,tow);
set(handles.T,'visible' , 'on' );
set(handles.text27,'visible' , 'on' );
set(handles.text29,'visible' , 'on' );
 
 
sample_rate=str2double(get(handles.sample_rate_hidden,'string'));



%  % now we should do sth for considering initial values: 
    model.kp.value=str2num(k2)*step_difference_for_modeling;
   [yy1,tt]=step(model,duration_time);
   yy1=yy1+ y_for_model(1);
   hold on
   plot(handles.axes1,tt,yy1,'r','markersize',5)
   
   [yy2,tt2]=step(model,duration_time);
   a=max(find(tt<0));
   tt2=tt2(a:end);
   yy2=yy2(a:end);
   plot(handles.axes1,tt2+duration_time,-yy2+yy1(length(yy1)),'r','markersize',5)
   
  pause(2)
question=questdlg(' Is The Model Satisfactory?  ',' Model ','Yes','No','Choose Another Model Type','Yes');
switch question
    case 'Yes'
set(handles.choose_model_history,'string',1);

set(handles.first_order_flag,'string',1);
set(handles.fopt_flag,'string',0);
set(handles.second_order_flag,'string',0);
set(handles.sopd_flag,'string',0);


k_for_tunning_parameters=str2double(k2);
tow_for_tunning_parameters=str2double(tow);

set(handles.measured_data_text,'visible' , 'on' );
set(handles.estimated_model_text,'visible' , 'on' );

    case 'No'
         plot(handles.axes1,tt,yy1,'w','markersize',5)
         plot(handles.axes1,tt2+duration_time,-yy2+yy1(length(yy1)),'w','markersize',5)
         first_order_Callback(hObject, eventdata, handles)
    case 'Choose Another Model Type'
        choice = menu('Choose Model Type: ','First Order Pluse Dead Time','Second Order '...
    ,'Second Order Pluse Dead Time','PointerLocation', [614 121]);
         plot(handles.axes1,tt,yy1,'w','markersize',5)
         plot(handles.axes1,tt2+duration_time,-yy2+yy1(length(yy1)),'w','markersize',5)
       if choice==1
           fopdt_Callback(hObject, eventdata, handles)
       end
       if choice==2
           second_order_Callback(hObject, eventdata, handles)
       end
       if choice==3
           sopdt_Callback(hObject, eventdata, handles)
       end
end

% --------------------------------------------------------------------
function fopdt_Callback(hObject, eventdata, handles)
% hObject    handle to fopdt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global y_for_model
global k_for_tunning_parameters deadtime_for_tunning_parameters tow_for_tunning_parameters


if str2double(get(handles.pulse_test_flag,'string'))==0;
    errordlg(' To Fit A Model You Should First Collect Data From Pulse Test Menu ')
    return
end


global y
global t
global step_difference_for_modeling
global sample_rate
global model duration_time
% y2=real(y(:,2));

sample_rate=str2double(get(handles.sample_rate_hidden,'string'));
% y2 : main tank
u=linspace(step_difference_for_modeling,step_difference_for_modeling,length( y_for_model));
u=transpose(u);
% iddata makes y and u and sample interval into a variabe suitable for
% n4sid

z=iddata( y_for_model,u,sample_rate);

%z estimate a model with order 1 (in this case) from iddata
% !!! (see also n4sid)
% n4sid: model is in state space , so we convert it to tf first, and convert it to
% continues time ( d2c : discrete to continues

prompt={'Minimum Guess For Time constant (sec) : ','Maximum Guess For Time constant (sec) : ',' Minimum Guess For Dead Time: (sec): ',' Maximum Guess For Dead Time: (sec): '};
   name=' Parameters Limit: ';
   numlines=1;

     defaultanswer={get(handles.Tp1_min_guess_hidden,'string'),get(handles.Tp1_max_guess_hidden,'string'),get(handles.Td_min_guess_hidden,'string'),get(handles.Td_max_guess_hidden,'string')};
   answer=inputdlg(prompt,name,numlines,defaultanswer,'on');
   if size(answer)==[0 0]
       return
   end
   
   if str2double(answer{2}) <= str2double(answer{1})
        % uiwait :
       % UIWAIT(FIG) blocks execution until either UIRESUME is called or
       % th
       uiwait( errordlg(' Maximum Guess Should Be Greater Than Minimum Guess ' ))
       fopdt_Callback(hObject, eventdata, handles)
       return
   end
   
   
   % I`m going to write new inputs in 4 hidden static texts to be saved for
    % next use:
   set(handles.Tp1_min_guess_hidden,'string',str2double(answer{1}))
   set(handles.Tp1_max_guess_hidden,'string',str2double(answer{2}))
   set(handles.Td_min_guess_hidden,'string',str2double(answer{3}))
   set(handles.Td_max_guess_hidden,'string',str2double(answer{4}))
  
   
   % processing sometimes take too much time, so we design a waiting alarm
% with red color
% we set everything invisible , so that in second or more tries we don`t
% see parameters from previous tests:
set(handles.text23,'string', ' Waiting . . . ');
set(handles.text23,'foregroundColor',[1 0 0]);
set(handles.text23,'visible', ' on');
set(handles.text24,'visible' , 'off' );
set(handles.text25,'visible' , 'off' );
set(handles.K,'visible' , 'off' );
set(handles.T,'visible' , 'off' );
set(handles.text27,'visible' , 'off' );
set(handles.text29,'visible' , 'off' );
set(handles.text52,'visible' , 'off' );
set(handles.text54,'visible' , 'off' );
set(handles.text58,'visible' , 'off' );
set(handles.text61,'visible' , 'off' );
set(handles.deadtime_static,'visible' , 'off' );
set(handles.second_time_constant_static,'visible' , 'off' ); 



model=pem(z,'P1D','Tp1',{'max',str2double(answer{2})},'Tp1',{'min',str2double(answer{1})},'Td',{'max',str2double(answer{4})},'Td',{'min',str2double(answer{3})});
% p1 means polonomyal first order

 
 k=model.kp.value;
 tow=model.Tp1.value;
 deadtime=model.Td.value;
 k2=(y_for_model(length(y_for_model))-y_for_model(1))/step_difference_for_modeling;
 
  % 2 floating point needed:
 tow=sprintf('%0.2f',tow);
 k2=sprintf('%0.2f',k2);
deadtime=sprintf('%0.2f',deadtime);
 
 
set(handles.text23,'string', ' First Order Parameters Plus Dead Time : ');
set(handles.text23,'foregroundColor',[0 0 0]);
% back to black!
set(handles.text23,'visible' , 'on' );
set(handles.text24,'visible' , 'on' );
set(handles.text25,'visible' , 'on' );
set(handles.K,'string' ,k2);
set(handles.K,'visible' , 'on' );
set(handles.T,'string' ,tow);
set(handles.T,'visible' , 'on' );
set(handles.text27,'visible' , 'on' );
set(handles.text29,'visible' , 'on' );
set(handles.text58,'visible' , 'on' );
set(handles.text61,'visible' , 'on' );
set(handles.deadtime_static,'visible' , 'on' );
set(handles.deadtime_static,'string' ,deadtime);


% 
% start_simulation_time=str2double(get(handles.start_simulation_hidden,'string'));
% end_simulation_time=str2double(get(handles.end_time_hidden,'string'));
sample_rate=str2double(get(handles.sample_rate_hidden,'string'));


    model.kp.value=str2num(k2)*step_difference_for_modeling;
   [yy1,tt]=step(model,duration_time);
   yy1=yy1+ y_for_model(1);
   hold on
   plot(handles.axes1,tt,yy1,'r','markersize',5)
   
   [yy2,tt2]=step(model,duration_time);
   a=max(find(tt<0));
   tt2=tt2(a:end);
   yy2=yy2(a:end);
   plot(handles.axes1,tt2+duration_time,-yy2+yy1(length(yy1)),'r','markersize',5)
   
  pause(2)
question=questdlg(' Is The Model Satisfactory?  ',' Model ','Yes','No','Choose Another Model Type','Yes');
switch question
    case 'Yes'
set(handles.choose_model_history,'string',1);

k_for_tunning_parameters=str2double(k2);
tow_for_tunning_parameters=str2double(tow);
deadtime_for_tunning_parameters=str2double(deadtime);


set(handles.first_order_flag,'string',0);
set(handles.fopt_flag,'string',1);
set(handles.second_order_flag,'string',0);
set(handles.sopd_flag,'string',0);

set(handles.measured_data_text,'visible' , 'on' );
set(handles.estimated_model_text,'visible' , 'on' );

    case 'No'
         plot(handles.axes1,tt,yy1,'w','markersize',5)
         plot(handles.axes1,tt2+duration_time,-yy2+yy1(length(yy1)),'w','markersize',5)
          fopdt_Callback(hObject, eventdata, handles)
   case 'Choose Another Model Type'
        choice = menu('Choose Model Type: ','First Order','Second Order '...
    ,'Second Order Pluse Dead Time');
         plot(handles.axes1,tt,yy1,'w','markersize',5)
         plot(handles.axes1,tt2+duration_time,-yy2+yy1(length(yy1)),'w','markersize',5)
       if choice==1
          first_order_Callback(hObject, eventdata, handles)
       end
       if choice==2
           second_order_Callback(hObject, eventdata, handles)
       end
       if choice==3
           sopdt_Callback(hObject, eventdata, handles)
       end
end

% --------------------------------------------------------------------
function second_order_Callback(hObject, eventdata, handles)
% hObject    handle to second_order (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

 
global k_for_tunning_parameters  tow_for_tunning_parameters tow2_for_tunning_parameters

if str2double(get(handles.pulse_test_flag,'string'))==0;
    errordlg(' To Fit A Model You Should First Collect Data From Pulse Test Menu ')
    return
end


global y
global t
global step_difference_for_modeling
global sample_rate
global model y_for_model duration_time
sample_rate=str2double(get(handles.sample_rate_hidden,'string'));
u=linspace(step_difference_for_modeling,step_difference_for_modeling,length( y_for_model));
u=transpose(u);
% iddata makes y and u and sample interval into a variabe suitable for
% n4sid

z=iddata( y_for_model,u,sample_rate);



prompt={'Minimum Guess For First Time constant (sec) : ','Maximum Guess For First Time constant (sec) : ',' Minimum Guess For Second Time Constamt: (sec): ',' Maximum Guess For Second Time Constant: (sec): '};
   name=' Parameters Limit: ';
   numlines=1;
   
  defaultanswer={get(handles.Tp1_min_guess_hidden,'string'),get(handles.Tp1_max_guess_hidden,'string'),get(handles.Tp2_min_guess_hidden,'string'),get(handles.Tp2_max_guess_hidden,'string')};

   answer=inputdlg(prompt,name,numlines,defaultanswer,'on');
   if size(answer)==[0 0]
       return
   end
   
   if str2double(answer{2}) <= str2double(answer{1}) | str2double(answer{4}) <= str2double(answer{3})
        % uiwait :
       % UIWAIT(FIG) blocks execution until either UIRESUME is called or
       % th
       uiwait( errordlg(' Maximum Guess Should Be Greater Than Minimum Guess ' ))
       second_order_Callback(hObject, eventdata, handles)
       return
   end
   
   
    % I`m going to write new inputs in 4 hidden static texts to be saved for
    % next use:
   set(handles.Tp1_min_guess_hidden,'string',str2double(answer{1}))
   set(handles.Tp1_max_guess_hidden,'string',str2double(answer{2}))
   set(handles.Tp2_min_guess_hidden,'string',str2double(answer{3}))
   set(handles.Tp2_max_guess_hidden,'string',str2double(answer{4}))
   
   % processing sometimes take too much time, so we design a waiting alarm
% with red color
% we set everything invisible , so that in second or more tries we don`t
% see parameters from previous tests:
set(handles.text23,'string', ' Waiting . . . ');
set(handles.text23,'foregroundColor',[1 0 0]);
set(handles.text23,'visible', ' on');
set(handles.text24,'visible' , 'off' );
set(handles.text25,'visible' , 'off' );
set(handles.K,'visible' , 'off' );
set(handles.T,'visible' , 'off' );
set(handles.text27,'visible' , 'off' );
set(handles.text29,'visible' , 'off' );
set(handles.text52,'visible' , 'off' );
set(handles.text54,'visible' , 'off' );
set(handles.text58,'visible' , 'off' );
set(handles.text61,'visible' , 'off' );
set(handles.deadtime_static,'visible' , 'off' );
set(handles.second_time_constant_static,'visible' , 'off' ); 


model=pem(z,'P2','Tp1',{'max',str2double(answer{2})},'Tp1',{'min',str2double(answer{1})},'Tp2',{'max',str2double(answer{4})},'Tp2',{'min',str2double(answer{3})});
% p2 means polonomyal second order

 
 k=model.kp.value;
 tow1=model.Tp1.value;
  tow2=model.Tp2.value;
 k2=(y_for_model(length( y_for_model))- y_for_model(1))/step_difference_for_modeling;

  % 2 floating point needed:
 tow1=sprintf('%0.2f',tow1);
 tow2=sprintf('%0.2f',tow2);
 k2=sprintf('%0.2f',k2);

 
 
set(handles.text23,'string', ' Second Order Parameters : ');
set(handles.text23,'foregroundColor',[0 0 0]);
% back to black!
set(handles.text23,'visible' , 'on' );
set(handles.text24,'visible' , 'on' );
set(handles.text25,'visible' , 'on' );
set(handles.K,'string' ,k2);
set(handles.K,'visible' , 'on' );
set(handles.T,'string' ,tow1);
set(handles.T,'visible' , 'on' );
set(handles.text27,'visible' , 'on' );
set(handles.text29,'visible' , 'on' );
set(handles.text58,'visible' , 'off' );
set(handles.text61,'visible' , 'off' );
set(handles.deadtime_static,'visible' , 'off' );
set(handles.text52,'visible' , 'on' );
set(handles.text54,'visible' , 'on' );
set(handles.second_time_constant_static,'string' ,tow2);
set(handles.second_time_constant_static,'visible' , 'on' ); 
% !!!!! this is what I wrote from the algorithm in chapter 2 of the book:
% logy=zeros(1,length(y)-1);
% alphat=zeros(1,length(y)-1);



sample_rate=str2double(get(handles.sample_rate_hidden,'string'));

    model.kp.value=str2num(k2)*step_difference_for_modeling;
   [yy1,tt]=step(model,duration_time);
   yy1=yy1+ y_for_model(1);
   hold on
   plot(handles.axes1,tt,yy1,'r','markersize',5)
   
   [yy2,tt2]=step(model,duration_time);
   a=max(find(tt<0));
   tt2=tt2(a:end);
   yy2=yy2(a:end);
   plot(handles.axes1,tt2+duration_time,-yy2+yy1(length(yy1)),'r','markersize',5)
   
  pause(2)
question=questdlg(' Is The Model Satisfactory?  ',' Model ','Yes','No','Choose Another Model Type','Yes');
switch question
    case 'Yes'
set(handles.choose_model_history,'string',1);

set(handles.first_order_flag,'string',0);
set(handles.fopt_flag,'string',0);
set(handles.second_order_flag,'string',1);
set(handles.sopd_flag,'string',0);

k_for_tunning_parameters=str2double(k2);
tow_for_tunning_parameters=str2double(tow1);
tow2_for_tunning_parameters=str2double(tow2);

set(handles.measured_data_text,'visible' , 'on' );
set(handles.estimated_model_text,'visible' , 'on' );

    case 'No'
         plot(handles.axes1,tt,yy1,'w','markersize',5)
         plot(handles.axes1,tt2+duration_time,-yy2+yy1(length(yy1)),'w','markersize',5)
         second_order_Callback(hObject, eventdata, handles)
   case 'Choose Another Model Type'
        choice = menu('Choose Model Type: ','First Order','First Order Pluse Dead Time '...
    ,'Second Order Pluse Dead Time');
         plot(handles.axes1,tt,yy1,'w','markersize',5)
         plot(handles.axes1,tt2+duration_time,-yy2+yy1(length(yy1)),'w','markersize',5)
       if choice==1
          first_order_Callback(hObject, eventdata, handles)
       end
       if choice==2
          fopdt_Callback(hObject, eventdata, handles)
       end
       if choice==3
           sopdt_Callback(hObject, eventdata, handles)
       end
end


 
% --------------------------------------------------------------------
function sopdt_Callback(hObject, eventdata, handles)
% hObject    handle to sopdt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


if str2double(get(handles.pulse_test_flag,'string'))==0;
    errordlg(' To Fit A Model You Should First Collect Data From Pulse Test Menu ')
    return
end


global y
global t
global step_difference_for_modeling
global sample_rate
global model y_for_model duration_time
global k_for_tunning_parameters deadtime_for_tunning_parameters tow_for_tunning_parameters tow2_for_tunning_parameters

sample_rate=str2double(get(handles.sample_rate_hidden,'string'));
u=linspace(step_difference_for_modeling,step_difference_for_modeling,length( y_for_model));
u=transpose(u);
% iddata makes y and u and sample interval into a variabe suitable for
% n4sid

z=iddata( y_for_model,u,sample_rate);


prompt={'Minimum Guess For First Time constant (sec) : ','Maximum Guess For First Time constant (sec) : ',' Minimum Guess For Second Time Constamt: (sec): ',' Maximum Guess For Second Time Constant: (sec): ',' Minimum Guess For Dead Time : (sec): ',' Maximum Guess For Dead Time : (sec): '};
   name=' Parameters Limit: ';
   numlines=1;
%      defaultanswer={'50','150','20','80','15','35'};

defaultanswer={get(handles.Tp1_min_guess_hidden,'string'),get(handles.Tp1_max_guess_hidden,'string'),get(handles.Tp2_min_guess_hidden,'string'),get(handles.Tp2_max_guess_hidden,'string'),get(handles.Td_min_guess_hidden,'string'),get(handles.Td_max_guess_hidden,'string')};
   answer=inputdlg(prompt,name,numlines,defaultanswer,'on');
   if size(answer)==[0 0]
       return
   end
   
   if str2double(answer{2}) <= str2double(answer{1}) | str2double(answer{4}) <= str2double(answer{3}) | str2double(answer{6}) <= str2double(answer{5})
        % uiwait :
       % UIWAIT(FIG) blocks execution until either UIRESUME is called or
       % th
       uiwait( errordlg(' Maximum Guess Should Be Greater Than Minimum Guess ' ))
       sopdt_Callback(hObject, eventdata, handles)
       return
   end
   
    % I`m going to write new inputs in 6 hidden static texts to be saved for
    % next use:
   set(handles.Tp1_min_guess_hidden,'string',str2double(answer{1}))
   set(handles.Tp1_max_guess_hidden,'string',str2double(answer{2}))
   set(handles.Tp2_min_guess_hidden,'string',str2double(answer{3}))
   set(handles.Tp2_max_guess_hidden,'string',str2double(answer{4}))
   set(handles.Td_min_guess_hidden,'string',str2double(answer{5}))
   set(handles.Td_max_guess_hidden,'string',str2double(answer{6}))
   
   % processing sometimes take too much time, so we design a waiting alarm
% with red color
% we set everything invisible , so that in second or more tries we don`t
% see parameters from previous tests:
set(handles.text23,'string', ' Waiting . . . ');
set(handles.text23,'foregroundColor',[1 0 0]);
set(handles.text23,'visible', ' on');
set(handles.text24,'visible' , 'off' );
set(handles.text25,'visible' , 'off' );
set(handles.K,'visible' , 'off' );
set(handles.T,'visible' , 'off' );
set(handles.text27,'visible' , 'off' );
set(handles.text29,'visible' , 'off' );
set(handles.text52,'visible' , 'off' );
set(handles.text54,'visible' , 'off' );
set(handles.text58,'visible' , 'off' );
set(handles.text61,'visible' , 'off' );
set(handles.deadtime_static,'visible' , 'off' );
set(handles.second_time_constant_static,'visible' , 'off' ); 




model=pem(z,'P2D','Tp1',{'max',str2double(answer{2})},'Tp1',{'min',str2double(answer{1})},'Tp2',{'max',str2double(answer{4})},'Tp2',{'min',str2double(answer{3})},'Td',{'max',str2double(answer{6})},'Td',{'min',str2double(answer{5})});
% p2D means polonomyal second order plus dead time

 
 k=model.kp.value;
 tow1=model.Tp1.value;
  tow2=model.Tp2.value;
   deadtime=model.Td.value;
 k2=(y_for_model(length( y_for_model))- y_for_model(1))/step_difference_for_modeling;
 
  % 2 floating point needed:
 tow1=sprintf('%0.2f',tow1);
 tow2=sprintf('%0.2f',tow2);
 deadtime=sprintf('%0.2f',deadtime);
 k2=sprintf('%0.2f',k2);

 
 
set(handles.text23,'string', ' Second Order Plus Dead Time Parameters : ');
set(handles.text23,'foregroundColor',[0 0 0]);
% back to black!
set(handles.text23,'visible' , 'on' );
set(handles.text24,'visible' , 'on' );
set(handles.text25,'visible' , 'on' );
set(handles.K,'string' ,k2);
set(handles.K,'visible' , 'on' );
set(handles.T,'string' ,tow1);
set(handles.T,'visible' , 'on' );
set(handles.text27,'visible' , 'on' );
set(handles.text29,'visible' , 'on' );

set(handles.deadtime_static,'visible' , 'on' );
set(handles.text52,'visible' , 'on' );
set(handles.text54,'visible' , 'on' );
set(handles.text58,'visible' , 'on' );
set(handles.text61,'visible' , 'on' );
set(handles.deadtime_static,'visible' , 'on' );
set(handles.deadtime_static,'string' ,deadtime);
set(handles.second_time_constant_static,'string' ,tow2);
set(handles.second_time_constant_static,'visible' , 'on' ); 
% !!!!! this is what I wrote from the algorithm in chapter 2 of the book:
% logy=zeros(1,length(y)-1);
% alphat=zeros(1,length(y)-1);






sample_rate=str2double(get(handles.sample_rate_hidden,'string'));

    model.kp.value=str2num(k2)*step_difference_for_modeling;
   [yy1,tt]=step(model,duration_time);
   yy1=yy1+ y_for_model(1);
   hold on
   plot(handles.axes1,tt,yy1,'r','markersize',5)
   
   [yy2,tt2]=step(model,duration_time);
   a=max(find(tt<0));
   tt2=tt2(a:end);
   yy2=yy2(a:end);
   plot(handles.axes1,tt2+duration_time,-yy2+yy1(length(yy1)),'r','markersize',5)
   
  pause(2)
question=questdlg(' Is The Model Satisfactory?  ',' Model ','Yes','No','Choose Another Model Type','Yes');
switch question
    case 'Yes'
set(handles.choose_model_history,'string',1);

set(handles.first_order_flag,'string',0);
set(handles.fopt_flag,'string',0);
set(handles.second_order_flag,'string',0);
set(handles.sopd_flag,'string',1);

k_for_tunning_parameters=str2double(k2);
tow_for_tunning_parameters=str2double(tow1);
deadtime_for_tunning_parameters=str2double(deadtime);
tow2_for_tunning_parameters=str2double(tow2);

set(handles.measured_data_text,'visible' , 'on' );
set(handles.estimated_model_text,'visible' , 'on' );

    case 'No'
         plot(handles.axes1,tt,yy1,'w','markersize',5)
         plot(handles.axes1,tt2+duration_time,-yy2+yy1(length(yy1)),'w','markersize',5)
         sopdt_Callback(hObject, eventdata, handles)
   case 'Choose Another Model Type'
        choice = menu('Choose Model Type: ','First Order','First Order Pluse Dead Time '...
    ,'Second Order ');
         plot(handles.axes1,tt,yy1,'w','markersize',5)
         plot(handles.axes1,tt2+duration_time,-yy2+yy1(length(yy1)),'w','markersize',5)
       if choice==1
          first_order_Callback(hObject, eventdata, handles)
       end
       if choice==2
          fopdt_Callback(hObject, eventdata, handles)
       end
       if choice==3
           second_order_Callback(hObject, eventdata, handles)
       end
end

% it means we have choosed a model to pid tuning parameters.
% --- Executes on slider movement.
function slider3_Callback(hObject, eventdata, handles)
% hObject    handle to slider3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function slider3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end



function reset_or_derive_time_edit_Callback(hObject, eventdata, handles)
% hObject    handle to reset_or_derive_time_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of reset_or_derive_time_edit as text
%        str2double(get(hObject,'String')) returns contents of reset_or_derive_time_edit as a double


% --- Executes during object creation, after setting all properties.
function reset_or_derive_time_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to reset_or_derive_time_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function derive_time_edit_Callback(hObject, eventdata, handles)
% hObject    handle to derive_time_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of derive_time_edit as text
%        str2double(get(hObject,'String')) returns contents of derive_time_edit as a double


% --- Executes during object creation, after setting all properties.
function derive_time_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to derive_time_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --------------------------------------------------------------------
function Untitled_3_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function hold_on_Callback(hObject, eventdata, handles)
% hObject    handle to hold_on (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
hold on
set(handles.hold_on,'checked','on')
set(handles.hold_off,'checked','off')

% --------------------------------------------------------------------
function hold_off_Callback(hObject, eventdata, handles)
% hObject    handle to hold_off (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
hold off
set(handles.hold_on,'checked','off')
set(handles.hold_off,'checked','on')


% --------------------------------------------------------------------
function compare_mode_Callback(hObject, eventdata, handles)
% hObject    handle to compare_mode (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

    % 1 means we are in compare mode
    % 0 means  we are in normal mode
    
if str2double(get(handles.flag_for_compare_mode,'string'))==0
    set(handles.flag_for_compare_mode,'string',1);

          set(handles.compare_mode,'checked','on')
        % the graph will be cleared to be ready for compare mode:
        
     cla(handles.axes1,'reset')
     
        return
end
if str2double(get(handles.flag_for_compare_mode,'string'))==1
    set(handles.flag_for_compare_mode,'string',0);
       set(handles.compare_mode,'checked','off')
       return
    
end


% --------------------------------------------------------------------
function clear_graph_Callback(hObject, eventdata, handles)
% hObject    handle to clear_graph (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
cla(handles.axes1,'reset')
cla(handles.axes10,'reset')


% --------------------------------------------------------------------
function Untitled_4_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function iae_Callback(hObject, eventdata, handles)
% hObject    handle to iae (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function ise_Callback(hObject, eventdata, handles)
% hObject    handle to ise (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function itae_Callback(hObject, eventdata, handles)
% hObject    handle to itae (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% global t
% global y
% global model
% global end_simulation_time
% if str2double(get(handles.flag_for_no_y_used_for_error,'string'))==0;
%     %0 means the user has choose fit model while there is no y!
%     errordlg(' There is no output to fit model ! ')
%     return
% end
% 
% if str2double(get(handles.choose_model_history,'string'))==0;
% % it means we have`nt choosen a model to pid tuning parameters.,'value')~=1;
%     errordlg(' To Tune Parameters, You Should First Choose A Model! ' )
%     return
% end
% s=[];
% for kp=0.05:0.05:5
%     model=tf(model);
%     model=tf(model.num{1},model.den{1},'inputdelay',model.inputdelay(1));
%     model=ss(model)
%     forward=series(kp,model);
%     closed_loop=feedback(forward,1);
%     [yy,tt]=step(closed_loop,end_simulation_time);
%     error=1-yy;
%     itae=tt.*abs(error);
%     temp=sum(itae);
%     
% %     if temp<s
% %         a=kp
% %     end
%     s=[s temp];
%     error=[];
%     itae=[];
% end
% 1
% a=find(s==min(s));
% kp=0.05:0.05:5
% kp(a)


% --------------------------------------------------------------------
function itse_Callback(hObject, eventdata, handles)
% hObject    handle to itse (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



function edit7_Callback(hObject, eventdata, handles)
% hObject    handle to edit7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit7 as text
%        str2double(get(hObject,'String')) returns contents of edit7 as a double


% --- Executes during object creation, after setting all properties.
function edit7_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit8_Callback(hObject, eventdata, handles)
% hObject    handle to edit8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit8 as text
%        str2double(get(hObject,'String')) returns contents of edit8 as a double


% --- Executes during object creation, after setting all properties.
function edit8_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit9_Callback(hObject, eventdata, handles)
% hObject    handle to edit9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit9 as text
%        str2double(get(hObject,'String')) returns contents of edit9 as a double


% --- Executes during object creation, after setting all properties.
function edit9_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function controller_bias_edit_Callback(hObject, eventdata, handles)
% hObject    handle to controller_bias_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of controller_bias_edit as text
%        str2double(get(hObject,'String')) returns contents of controller_bias_edit as a double


% --- Executes during object creation, after setting all properties.
function controller_bias_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to controller_bias_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --------------------------------------------------------------------
function pulse_test_Callback(hObject, eventdata, handles)
% hObject    handle to pulse_test (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global inlet
global dis
global y_for_model y_memory
global step_difference_for_modeling duration_time


   
          if get(handles.cntr_menu,'value')~=1
      % uiwait :
      % UIWAIT(FIG) blocks execution until either UIRESUME is called or the
      % figure FIG is destroyed (closed)
      uiwait(errordlg('The system should be in manual mode for pulse test', ' Error: '));
         return
          end
          
          

prompt={' First Input Flowrate (cm^3/sec) : ','Second Input Flowrate (cm^3/sec)','  Second Input Flowrate Duration (sec),' };
   name=' Pulse Test : ';
   numlines=1;
%      defaultanswer={'20','25','400'};
 defaultanswer={get(handles.first_input_model_hidden,'string'),get(handles.second_input_model_hidden,'string'),get(handles.duration_fit_mode_hidden,'string')};
   answer=inputdlg(prompt,name,numlines,defaultanswer,'on');
   if size(answer)==[0 0]
       return
   end
   
   set(handles.axes10_title,'string','Manual Input (cm^3/sec) :')
   
   first_inlet=str2double(answer{1});
   second_inlet=str2double(answer{2});
   duration_time=str2double(answer{3});
   
          if first_inlet>second_inlet
      % uiwait :
      % UIWAIT(FIG) blocks execution until either UIRESUME is called or the
      % figure FIG is destroyed (closed)
      uiwait(errordlg('Second Input Flowrate Should Be Greater Than First One ', ' Error: '));
      pulse_test_Callback(hObject, eventdata, handles)
      return
          end
   
          if first_inlet>25 || second_inlet>25
      % uiwait :
      % UIWAIT(FIG) blocks execution until either UIRESUME is called or the
      % figure FIG is destroyed (closed)
      uiwait(errordlg('Process input should be less than 25 CM^3/sec ', ' Error: '));
      pulse_test_Callback(hObject, eventdata, handles)
      return
          end
          if first_inlet<1 || second_inlet<1
      % uiwait :
      % UIWAIT(FIG) blocks execution until either UIRESUME is called or the
      % figure FIG is destroyed (closed)
      uiwait(errordlg('Process input should be more than 1 CM^3/sec ', ' Error: '));
      pulse_test_Callback(hObject, eventdata, handles)
       return
          end
          
           if duration_time<500
      % uiwait :
      % UIWAIT(FIG) blocks execution until either UIRESUME is called or the
      % figure FIG is destroyed (closed)
      uiwait(errordlg('It`s Better to choose a time more than 500sec for duration time, so the system can reach its steady state', 'warning '));
          end
          
          
          
              % max disturbance error : 
    if dis>10
        errordlg('Maximum Process disturbance is 10 CM^3/sec ', ' Error: ');
        set(handles.dis_flowrate,'string',10)
        return
    end
    % max disturbance error : 
    if dis<0
        errordlg('Minimum Process disturbance is 0 CM^3/sec ', ' Error: ');
        return
    end
   
    

      set(handles.first_input_model_hidden,'string',first_inlet)
      set(handles.second_input_model_hidden,'string',second_inlet)
      set(handles.duration_fit_mode_hidden,'string',duration_time)
 

           axes(handles.axes9)
               moon = imread('gheichi.jpg');
imshow(moon)
      
           
           
 high_level_alarm=str2double(get(handles.high_alarm_hidden,'string'));
 low_level_alarm=str2double(get(handles.low_alarm_hidden,'string'));
      
%    start_simulation_time=str2double(get(handles.start_simulation_hidden,'string'));
    end_simulation_time=str2double(get(handles.end_time_hidden,'string'));
    sample_rate=str2double(get(handles.sample_rate_hidden,'string'));
    pause_time=str2double(get(handles.pause_time_hidden,'string'));





   %%%%%%%%%%%% reach initial variables with first input :
           upper_tank_initial_level=str2double(get(handles.upper_tank_initial_level_hidden,'string'));
           main_tank_initial_level=str2double(get(handles.main_tank_initial_level_hidden,'string'));
           
           inlet=first_inlet;
           
           dis=str2double(get(handles.dis_flowrate,'string'));
    

      [t,y]=ode45(@myfun,[0:sample_rate:end_simulation_time],[upper_tank_initial_level main_tank_initial_level]);
                set(handles.upper_tank_initial_level_hidden,'string',y(size(y,1),1))
                 set(handles.main_tank_initial_level_hidden,'string',y(size(y,1),2))

       
 %%%%%%%%%%%%%%%%%%%%%  
   


%reading initial level:
upper_tank_initial_level=str2double(get(handles.upper_tank_initial_level_hidden,'string'));
main_tank_initial_level=str2double(get(handles.main_tank_initial_level_hidden,'string'));

% solving:
%     [t,y]=ode45(@myfun,[0:sample_rate:duration_time],[upper_tank_initial_level main_tank_initial_level]);
%     
    
    %input Plotting:
    
        cla(handles.axes1,'reset')
        cla(handles.axes10,'reset')
    
    
    zero_time= duration_time/8;
    hold(handles.axes10,'on');
    plot(handles.axes10,[-zero_time 0],[first_inlet first_inlet],'r','markersize',5);
    plot(handles.axes10,[0 0],[first_inlet second_inlet],'r','markersize',5);
    plot(handles.axes10,[0 duration_time],[second_inlet second_inlet],'r','markersize',5);
    plot(handles.axes10,[duration_time duration_time],[second_inlet first_inlet],'r','markersize',5);
    plot(handles.axes10,[duration_time 2*duration_time],[first_inlet first_inlet],'r','markersize',5);
    axis(handles.axes10,[-zero_time 2*duration_time first_inlet-2 second_inlet+2])
    
    
         inlet=second_inlet;
         [t,y]=ode45(@myfun,(0:sample_rate:duration_time),[upper_tank_initial_level main_tank_initial_level]);
         y1=y;
    
    
    % plotting time zero level:
     t_for_zero_time_plot=[-zero_time:sample_rate:0];
     
        hold(handles.axes1,'on');
        plot(handles.axes1,t_for_zero_time_plot,linspace(main_tank_initial_level,main_tank_initial_level,length(t_for_zero_time_plot)),'b.','markersize',5);
        axis(handles.axes1,[-zero_time 2*duration_time real(min(y(:,2)))-10 real(max(y(:,2)))+10])
       
        
        
        
        %%%%%%%%%% ploting second input : 
     previous_main_tank_level=0;
     previous_upper_tank_level=0;
     set(handles.inlet_flowrate_static,'string',second_inlet);
     set(handles.inlet_flowrate_edit,'string',second_inlet);

    t_for_first_input_plot=[0:sample_rate:duration_time];

    for i=1:length( t_for_first_input_plot)


         axis(handles.axes1,[-zero_time 2*duration_time real(min(y1(:,2)))-10 real(max(y1(:,2)))+10])
       
     plot(handles.axes1,t_for_first_input_plot(i),real(y1(i,2)),'b.:','markersize',5)
   
    
% making the name for picture and set it to axes :
% to make the program faster we compare previous level with current one:
%main tank:
if floor(real(y(i,2)))~= previous_main_tank_level
picname=strcat('tank',num2str(floor(real(y(i,2)))),'.jpg');
axes(handles.axes6);
imread(picname);
imshow(picname);
% hold gheichi! :
axes(handles.axes9)
hold on

pause(0.00001)
  
end
 previous_main_tank_level=floor(real(y(i,2)));
 % upper tank:
if floor(real(y(i,1)))~=previous_upper_tank_level
picname=strcat('tanku',num2str(floor(real(y(i,1)))),'.jpg');
axes(handles.axes8);
imread(picname);
imshow(picname);
% hold gheichi! :
axes(handles.axes9)
hold on
pause(0.00001)
end  
previous_upper_tank_level=floor(real(y(i,1)));
    
    
             % alarms:
        if real(y(i,2))>high_level_alarm 
            set(handles.high_alarm,'visible','on')
            pause(0.03)
            set(handles.high_alarm,'visible','off')
        end

        if real(y(i,2))<low_level_alarm
            set(handles.low_alarm,'visible','on')
            pause(0.03)
            set(handles.low_alarm,'visible','off')
        end
      
    %writing levels and outlet:
    set(handles.level_static,'string',sprintf('%0.2f',real(y1(i,2))))
    set(handles.level_static_upper_tank,'string',sprintf('%0.2f',real(y1(i,1))))
    set(handles.outlet_flowrate,'string',sprintf('%0.2f',inlet-dis))

    % sprintf has been used to select 2 floating point to show
    set(handles.time_static,'string',sprintf('%0.2f',t_for_first_input_plot(i)));
   
         hold(handles.axes1,'on')
               pause(pause_time)
               

    end
    
    
    
    
    
    
    
    
    
    
    
      set(handles.upper_tank_initial_level_hidden,'string',y(size(y,1),1))
      set(handles.main_tank_initial_level_hidden,'string',y(size(y,1),2))
    
       upper_tank_initial_level=str2double(get(handles.upper_tank_initial_level_hidden,'string'));
       main_tank_initial_level=str2double(get(handles.main_tank_initial_level_hidden,'string'));
    
         t_for_second_input_plot=[duration_time:sample_rate:2*duration_time];
         inlet=first_inlet;
         [t,y]=ode45(@myfun, t_for_second_input_plot,[upper_tank_initial_level main_tank_initial_level]);
                        set(handles.upper_tank_initial_level_hidden,'string',y(size(y,1),1))
                        set(handles.main_tank_initial_level_hidden,'string',y(size(y,1),2))
         y2=y;
    
    
    
         
         
         
         
 
            %%%%%%%%%% ploting First input : 
     previous_main_tank_level=0;
     previous_upper_tank_level=0;
     set(handles.inlet_flowrate_static,'string',first_inlet);
     set(handles.inlet_flowrate_edit,'string',first_inlet);
     

    for i=1:length( t_for_second_input_plot)


         axis(handles.axes1,[-zero_time 2*duration_time real(min(y1(:,2)))-10 real(max(y1(:,2)))+10])
         plot(handles.axes1,t_for_second_input_plot(i),real(y2(i,2)),'b.:','markersize',5)
   
    
% making the name for picture and set it to axes :
% to make the program faster we compare previous level with current one:
%main tank:
if floor(real(y(i,2)))~= previous_main_tank_level
picname=strcat('tank',num2str(floor(real(y(i,2)))),'.jpg');
axes(handles.axes6);
imread(picname);
imshow(picname);
% hold gheichi! :
axes(handles.axes9)
hold on

pause(0.00001)
  
end
 previous_main_tank_level=floor(real(y(i,2)));
 % upper tank:
if floor(real(y(i,1)))~=previous_upper_tank_level
picname=strcat('tanku',num2str(floor(real(y(i,1)))),'.jpg');
axes(handles.axes8);
imread(picname);
imshow(picname);
% hold gheichi! :
axes(handles.axes9)
hold on
pause(0.00001)
end  
previous_upper_tank_level=floor(real(y(i,1)));
    
    
             % alarms:
        if real(y(i,2))>high_level_alarm 
            set(handles.high_alarm,'visible','on')
            pause(0.03)
            set(handles.high_alarm,'visible','off')
        end

        if real(y(i,2))<low_level_alarm
            set(handles.low_alarm,'visible','on')
            pause(0.03)
            set(handles.low_alarm,'visible','off')
        end
      
    %writing levels and outlet:
    set(handles.level_static,'string',sprintf('%0.2f',real(y2(i,2))))
    set(handles.level_static_upper_tank,'string',sprintf('%0.2f',real(y2(i,1))))
    set(handles.outlet_flowrate,'string',sprintf('%0.2f',inlet-dis))

    % sprintf has been used to select 2 floating point to show
    set(handles.time_static,'string',sprintf('%0.2f',t_for_second_input_plot(i)));
   
         hold(handles.axes1,'on')
               pause(pause_time)
               

    end

     
y_for_model=y1(:,2);
step_difference_for_modeling=second_inlet - first_inlet;    



set(handles.pulse_test_flag,'string',1);
y_memory=y2(:,2);
     a=get(handles.grid_on,'checked');
 switch a
     case 'on'
         set(handles.axes1,'ygrid','on')
         set(handles.axes1,'xgrid','on')
         
         set(handles.axes10,'ygrid','on')
         set(handles.axes10,'xgrid','on')
         
        
     case 'off'
         set(handles.axes1,'ygrid','off')
         set(handles.axes1,'xgrid','off')
         
         set(handles.axes10,'ygrid','off')
         set(handles.axes10,'xgrid','off')
 end


% --------------------------------------------------------------------
function cohen_coon_Callback(hObject, eventdata, handles)
% hObject    handle to cohen_coon (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function cohen_p_Callback(hObject, eventdata, handles)
% hObject    handle to cohen_p (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global tow_for_tunning_parameters
global k_for_tunning_parameters
global deadtime_for_tunning_parameters


if str2double(get(handles.choose_model_history,'string'))~=1
 errordlg('You Should First Derive A Model For System With Puls Test And Fit Model Menu', ' Error: ');
 return 
end

if str2double(get(handles.first_order_flag,'string'))==1 || str2double(get(handles.second_order_flag,'string'))==1 ...
        || str2double(get(handles.sopd_flag,'string'))==1 
 errordlg('Cohen Coon Method Is Only Available For First Order Plus Dead Time Model. ', ' Error: ');
  return 
end

set(handles.contoroller_gain_text_paramaters,'visible','off');
set(handles.controller_gain_number,'visible','off');

set(handles.reset_time_text_paramaters,'visible','off');
set(handles.reset_time_number,'visible','off');

set(handles.derive_time_text_paramaters,'visible','off');
set(handles.derive_time_number,'visible','off');

set(handles.title_for_parameters,'visible','off');




tow=tow_for_tunning_parameters;
deadtime=deadtime_for_tunning_parameters;
k=k_for_tunning_parameters;

r=deadtime/tow;

kp=(1/(k*r))*(1+r/3);


set(handles.controller_gain_number,'string',sprintf('%0.2f',kp));
set(handles.controller_gain_number,'visible','on');
set(handles.contoroller_gain_text_paramaters,'visible','on');

set(handles.title_for_parameters,'string','Cohen-Coon P-only Parameters :');
set(handles.title_for_parameters,'visible','on');


% --------------------------------------------------------------------
function cohen_PI_Callback(hObject, eventdata, handles)
% hObject    handle to cohen_PI (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global tow_for_tunning_parameters
global k_for_tunning_parameters
global deadtime_for_tunning_parameters

if str2double(get(handles.choose_model_history,'string'))~=1
 errordlg('You Should First Derive A Model For System With Puls Test And Fit Model Menu', ' Error: ');
 return 
end


if str2double(get(handles.first_order_flag,'string'))==1 || str2double(get(handles.second_order_flag,'string'))==1 ...
        || str2double(get(handles.sopd_flag,'string'))==1 
 errordlg('Cohen Coon Method Is Only Available For First Order Plus Dead Time Model. ', ' Error: ');
  return 
end


set(handles.contoroller_gain_text_paramaters,'visible','off');
set(handles.controller_gain_number,'visible','off');

set(handles.reset_time_text_paramaters,'visible','off');
set(handles.reset_time_number,'visible','off');

set(handles.derive_time_text_paramaters,'visible','off');
set(handles.derive_time_number,'visible','off');

set(handles.title_for_parameters,'visible','off');



tow=tow_for_tunning_parameters;
deadtime=deadtime_for_tunning_parameters;
k=k_for_tunning_parameters;

r=deadtime/tow;

kp=(1/(k*r))*(0.9+r/12);
reset_time_cohen=deadtime*(30+3*r)/(9+20*r);



set(handles.controller_gain_number,'string',sprintf('%0.2f',kp));
set(handles.controller_gain_number,'visible','on');
set(handles.contoroller_gain_text_paramaters,'visible','on');

set(handles.reset_time_number,'string',sprintf('%0.2f',reset_time_cohen));
set(handles.reset_time_number,'visible','on');
set(handles.reset_time_text_paramaters,'visible','on');

set(handles.title_for_parameters,'string','Cohen-Coon PI Parameters :');
set(handles.title_for_parameters,'visible','on');



% --------------------------------------------------------------------
function cohen_PID_Callback(hObject, eventdata, handles)
% hObject    handle to cohen_PID (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global tow_for_tunning_parameters
global k_for_tunning_parameters
global deadtime_for_tunning_parameters



if str2double(get(handles.choose_model_history,'string'))~=1
 errordlg('You Should First Derive A Model For System With Puls Test And Fit Model Menu', ' Error: ');
 return 
end


if str2double(get(handles.first_order_flag,'string'))==1 || str2double(get(handles.second_order_flag,'string'))==1 ...
        || str2double(get(handles.sopd_flag,'string'))==1 
 errordlg('Cohen Coon Method Is Only Available For First Order Plus Dead Time Model. ', ' Error: ');
 return 
end



set(handles.contoroller_gain_text_paramaters,'visible','off');
set(handles.controller_gain_number,'visible','off');

set(handles.reset_time_text_paramaters,'visible','off');
set(handles.reset_time_number,'visible','off');

set(handles.derive_time_text_paramaters,'visible','off');
set(handles.derive_time_number,'visible','off');

set(handles.title_for_parameters,'visible','off');



tow=tow_for_tunning_parameters;
deadtime=deadtime_for_tunning_parameters;
k=k_for_tunning_parameters;

r=deadtime/tow;

kp=(1/(k*r))*(4/3+r/4);
reset_time_cohen=deadtime*(32+6*r)/(13+8*r);
derive_time_cohen=4*deadtime/(11+2*r);


set(handles.controller_gain_number,'string',sprintf('%0.2f',kp));
set(handles.controller_gain_number,'visible','on');
set(handles.contoroller_gain_text_paramaters,'visible','on');

set(handles.reset_time_number,'string',sprintf('%0.2f',reset_time_cohen));
set(handles.reset_time_number,'visible','on');
set(handles.reset_time_text_paramaters,'visible','on');

set(handles.derive_time_number,'string',sprintf('%0.2f',derive_time_cohen));
set(handles.derive_time_number,'visible','on');
set(handles.derive_time_text_paramaters,'visible','on');

set(handles.title_for_parameters,'string','Cohen-Coon PID Parameters :');
set(handles.title_for_parameters,'visible','on');


% --------------------------------------------------------------------
function Untitled_5_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function imc_PI_Callback(hObject, eventdata, handles)
% hObject    handle to imc_PI (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global tow_for_tunning_parameters
global k_for_tunning_parameters
global deadtime_for_tunning_parameters

if str2double(get(handles.choose_model_history,'string'))~=1
 errordlg('You Should First Derive A Model For System With Puls Test And Fit Model Menu', ' Error: ');
 return 
end


if str2double(get(handles.second_order_flag,'string'))==1 || str2double(get(handles.sopd_flag,'string'))==1
 errordlg('IMC Method For PI Tuning Is Only Available For First Order Or First Order Plus Dead Time Models. ', ' Error: ');
 return 
end


set(handles.contoroller_gain_text_paramaters,'visible','off');
set(handles.controller_gain_number,'visible','off');

set(handles.reset_time_text_paramaters,'visible','off');
set(handles.reset_time_number,'visible','off');

set(handles.derive_time_text_paramaters,'visible','off');
set(handles.derive_time_number,'visible','off');

set(handles.title_for_parameters,'visible','off');


%%%%%%%%%%%%%%%%%%%%%%%%% For First Order Plus Dead
if str2double(get(handles.fopt_flag,'string'))==1
    

% reset time eqauls to time constant in first order model:
set(handles.reset_time_number,'string',tow_for_tunning_parameters);


tow_c=max([0.8*deadtime_for_tunning_parameters        0.1*tow_for_tunning_parameters]);
k_imc=(1/k_for_tunning_parameters)  *   (tow_for_tunning_parameters/(tow_c  +  deadtime_for_tunning_parameters));




set(handles.controller_gain_number,'string',sprintf('%0.2f',k_imc));
set(handles.controller_gain_number,'visible','on');
set(handles.contoroller_gain_text_paramaters,'visible','on');

set(handles.reset_time_number,'string',sprintf('%0.2f',tow_for_tunning_parameters));
set(handles.reset_time_number,'visible','on');
set(handles.reset_time_text_paramaters,'visible','on');

set(handles.title_for_parameters,'string','IMC PI Parameters :');
set(handles.title_for_parameters,'visible','on');

end

%%%%%%%%%%%%%%%%%%% First order

if str2double(get(handles.first_order_flag,'string'))==1
    

% reset time eqauls to time constant in first order model:
set(handles.reset_time_number,'string',tow_for_tunning_parameters);


tow_c=0.1*tow_for_tunning_parameters;
k_imc=(1/k_for_tunning_parameters)  *   (tow_for_tunning_parameters/(tow_c ));




set(handles.controller_gain_number,'string',sprintf('%0.2f',k_imc));
set(handles.controller_gain_number,'visible','on');
set(handles.contoroller_gain_text_paramaters,'visible','on');

set(handles.reset_time_number,'string',sprintf('%0.2f',tow_for_tunning_parameters));
set(handles.reset_time_number,'visible','on');
set(handles.reset_time_text_paramaters,'visible','on');

set(handles.title_for_parameters,'string','IMC PI Parameters :');
set(handles.title_for_parameters,'visible','on');

end



% --------------------------------------------------------------------
function imc_PID_Callback(hObject, eventdata, handles)
% hObject    handle to imc_PID (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global tow_for_tunning_parameters
global k_for_tunning_parameters
global deadtime_for_tunning_parameters
global tow2_for_tunning_parameters

if str2double(get(handles.choose_model_history,'string'))~=1
 errordlg('You Should First Derive A Model For System With Puls Test And Fit Model Menu', ' Error: ');
 return 
end


if str2double(get(handles.first_order_flag,'string'))==1 || str2double(get(handles.fopt_flag,'string'))==1
 errordlg('IMC Method For PID Tuning Is Only Available For Second Order Or Second Order Plus Dead Time Models. ', ' Error: ');
 return 
end


    
    
set(handles.contoroller_gain_text_paramaters,'visible','off');
set(handles.controller_gain_number,'visible','off');

set(handles.reset_time_text_paramaters,'visible','off');
set(handles.reset_time_number,'visible','off');

set(handles.derive_time_text_paramaters,'visible','off');
set(handles.derive_time_number,'visible','off');

set(handles.title_for_parameters,'visible','off');


%%%%%%%%%%%%%%%%%%%%%%%%%%% SOPDT
if str2double(get(handles.sopd_flag,'string'))==1


tow_c=max([0.8*deadtime_for_tunning_parameters        0.1*tow_for_tunning_parameters  0.1*tow2_for_tunning_parameters  ]);

k_imc=(1/k_for_tunning_parameters)  *   ((tow_for_tunning_parameters + tow2_for_tunning_parameters) /(tow_c  +  deadtime_for_tunning_parameters));
Ti_imc= tow_for_tunning_parameters + tow2_for_tunning_parameters;
Td_imc= (tow_for_tunning_parameters * tow2_for_tunning_parameters)/(tow_for_tunning_parameters + tow2_for_tunning_parameters);


set(handles.controller_gain_number,'string',sprintf('%0.2f',k_imc));
set(handles.controller_gain_number,'visible','on');
set(handles.contoroller_gain_text_paramaters,'visible','on');

set(handles.reset_time_number,'string',sprintf('%0.2f',Ti_imc));
set(handles.reset_time_number,'visible','on');
set(handles.reset_time_text_paramaters,'visible','on');

set(handles.derive_time_number,'string',sprintf('%0.2f',Td_imc));
set(handles.derive_time_number,'visible','on');
set(handles.derive_time_text_paramaters,'visible','on');


set(handles.title_for_parameters,'string','IMC PID Parameters :');
set(handles.title_for_parameters,'visible','on');

end


%%%%%%%%%%%%%% second order

if str2double(get(handles.second_order_flag,'string'))==1


tow_c=0.1*( tow_for_tunning_parameters + tow2_for_tunning_parameters);

k_imc=(1/k_for_tunning_parameters)  *   (tow_for_tunning_parameters + tow2_for_tunning_parameters) /(tow_c );
Ti_imc= tow_for_tunning_parameters + tow2_for_tunning_parameters;
Td_imc= (tow_for_tunning_parameters * tow2_for_tunning_parameters)/(tow_for_tunning_parameters + tow2_for_tunning_parameters);


set(handles.controller_gain_number,'string',sprintf('%0.2f',k_imc));
set(handles.controller_gain_number,'visible','on');
set(handles.contoroller_gain_text_paramaters,'visible','on');

set(handles.reset_time_number,'string',sprintf('%0.2f',Ti_imc));
set(handles.reset_time_number,'visible','on');
set(handles.reset_time_text_paramaters,'visible','on');

set(handles.derive_time_number,'string',sprintf('%0.2f',Td_imc));
set(handles.derive_time_number,'visible','on');
set(handles.derive_time_text_paramaters,'visible','on');


set(handles.title_for_parameters,'string','IMC PID Parameters :');
set(handles.title_for_parameters,'visible','on');

end


% --------------------------------------------------------------------
function axes_setting_Callback(hObject, eventdata, handles)
% hObject    handle to axes_setting (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% --------------------------------------------------------------------
function print_figure_Callback(hObject, eventdata, handles)
% hObject    handle to print_figure (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
printpreview(Gravity_drained_tank)


% --------------------------------------------------------------------
function exit_menu_Callback(hObject, eventdata, handles)
% hObject    handle to exit_menu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

a=questdlg(' Do You Want To Exit ? ',' Exit ','Yes','No','Yes');
switch a
    case 'Yes'
        close( 'Gravity_drained_tank')
end


% --------------------------------------------------------------------
function axis_measured_level_graph_Callback(hObject, eventdata, handles)
% hObject    handle to axis_measured_level_graph (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



   prompt={' Start Time : ', 'End Time : ' ,' Start Level : ', 'End Level : ' };
   name=' Axes Limits ';
   numlines=1;
     pre_x_axes=get(handles.axes1,'xlim');
     pre_y_axes=get(handles.axes1,'ylim');
     defaultanswer={num2str(pre_x_axes(1)),num2str(pre_x_axes(2)),num2str(pre_y_axes(1)),num2str(pre_y_axes(2)) };
     
   answer=inputdlg(prompt,name,numlines,defaultanswer,'on');
   if size(answer)==[0 0]
       return
   end
    
    set(handles.axes1,'xlim',[str2double(answer{1}) str2double(answer{2})]);
    set(handles.axes1,'ylim',[str2double(answer{3}) str2double(answer{4})]);



% --------------------------------------------------------------------
function input_axis_graph_Callback(hObject, eventdata, handles)
% hObject    handle to input_axis_graph (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


       prompt={' Start Time : ', 'End Time : ' ,' Start Y : ', 'End Y : ' };
   name=' Axes Limits ';
   numlines=1;
     pre_x_axes=get(handles.axes10,'xlim');
     pre_y_axes=get(handles.axes10,'ylim');
     defaultanswer={num2str(pre_x_axes(1)),num2str(pre_x_axes(2)),num2str(pre_y_axes(1)),num2str(pre_y_axes(2)) };
     
   answer=inputdlg(prompt,name,numlines,defaultanswer,'on');
   if size(answer)==[0 0]
       return
   end
    
    set(handles.axes10,'xlim',[str2double(answer{1}) str2double(answer{2})]);
    set(handles.axes10,'ylim',[str2double(answer{3}) str2double(answer{4})]);
    


% --------------------------------------------------------------------
function file_new_Callback(hObject, eventdata, handles)
% hObject    handle to file_new (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


cla(handles.axes1,'reset')
cla(handles.axes10,'reset')

% first step is to set initial pictures on appropirate axes
% axes(handles.axes6) concentrates on a axes 6 ! 
   axes(handles.axes6)
   imshow('tank49.jpg',handles.axes6)
   axes(handles.axes8)
   imshow('tanku64.jpg',handles.axes8)
   axes(handles.axes9)
   imshow('gheichi.jpg',handles.axes9)
   
 set(handles.axes10,'xtick',[])

      set(handles.inlet_flowrate_static,'string',20);
      set(handles. upper_tank_full,'visible','off');
      set(handles.level_static_upper_tank,'string',64);
      
      set(handles.level_static,'string',49);
      set(handles.dis_flowrate,'string',2.5);
      set(handles.outlet_flowrate,'string',12.5);
      set(handles.high_alarm,'visible','off');
       set(handles.low_alarm,'visible','off');
 
      set(handles.cntr_menu,'value',1);
     axes(handles.axes9)
    imshow('gheichi.jpg',handles.axes9)
set(handles.open_or_closed_loop_level_static,'string','Open Loop Level: ');
set(handles.input_static,'visible','on');
set(handles.inlet_flowrate_edit,'visible','on');
set(handles.gc_static2,'visible','off');
set(handles.text72,'visible','off');
set(handles.text75,'visible','off');
set(handles.line_in_gc,'visible','off');
set(handles.text73,'visible','off');
set(handles.text69,'visible','off');
set(handles.controller_bias_static,'visible','off');
set(handles.controller_bias_edit,'visible','off');
set(handles.text74,'visible','off');
set(handles.set_point_static,'visible','off');
set(handles.set_point_edit,'visible','off');
set(handles.set_point_edit,'visible','off');

set(handles.controller_gain_edit,'visible','off');

set(handles.reset_or_derive_time_edit,'visible','off');
set(handles.derive_time_edit,'visible','off');




set(handles.text23,'visible', ' off');
set(handles.text24,'visible' , 'off' );
set(handles.text25,'visible' , 'off' );
set(handles.K,'visible' , 'off' );
set(handles.T,'visible' , 'off' );
set(handles.text27,'visible' , 'off' );
set(handles.text29,'visible' , 'off' );
set(handles.text52,'visible' , 'off' );
set(handles.text54,'visible' , 'off' );
set(handles.text58,'visible' , 'off' );
set(handles.text61,'visible' , 'off' );
set(handles.deadtime_static,'visible' , 'off' );
set(handles.second_time_constant_static,'visible' , 'off' ); 



set(handles.contoroller_gain_text_paramaters,'visible','off');
set(handles.controller_gain_number,'visible','off');

set(handles.reset_time_text_paramaters,'visible','off');
set(handles.reset_time_number,'visible','off');

set(handles.derive_time_text_paramaters,'visible','off');
set(handles.derive_time_number,'visible','off');

set(handles.title_for_parameters,'visible','off');

set(handles.measured_data_text,'visible','off');
set(handles.estimated_model_text,'visible','off');



  set(handles.upper_tank_initial_level_hidden,'string',64);
  set(handles.main_tank_initial_level_hidden,'string',49);
  set(handles.flag_for_no_y_used_for_error,'string',0);
  set(handles.start_simulation_hidden,'string',-200);
  set(handles.pause_time_hidden,'string',0.01);
  
  set(handles.end_time_hidden,'string',600);
  set(handles.sample_rate_hidden,'string',5);
  set(handles.input_hidden,'string',20);
  set(handles.stop_pushbutton_hidden,'string',0);
  set(handles.flag_for_compare_mode,'string',0);  
  set(handles.choose_model_history,'string',0);
  set(handles.Tp1_max_guess_hidden,'string',150);
  set(handles.Tp1_min_guess_hidden,'string',50);
  set(handles.Tp2_min_guess_hidden,'string',20);
  set(handles.Tp2_max_guess_hidden,'string',80);      

  set(handles.Td_max_guess_hidden,'string',25);
  set(handles.Td_min_guess_hidden,'string',15);  
  set(handles.simulation_counter,'string',0);
  set(handles.contoller_output_counter,'string',0);
  set(handles.pulse_test_flag,'string',0);
  set(handles.first_input_model_hidden,'string',20);

  
  
  set(handles.second_input_model_hidden,'string',25);
  set(handles.duration_fit_mode_hidden,'string',600);  
  set(handles.first_order_flag,'string',0);
  set(handles.fopt_flag,'string',0);
  set(handles.second_order_flag,'string',0);
  set(handles.sopd_flag,'string',0);
  set(handles.time_static,'string',0);
  
  set(handles.low_alarm_hidden,'string',10);
    set(handles.high_alarm_hidden,'string',80);
     
  set(handles.k_minimum_hidden,'string',0.3);
    set(handles.k_maximum_hidden,'string',3.2);
     
  set(handles.r_time_maximum_hidden,'string',150);
    set(handles.r_time_minimum_hidden,'string',50);
     
  set(handles.d_time_minimum_hidden,'string',5);
    set(handles.d_time_maximum_hidden,'string',150);
    
    
  axis(handles.axes1,[0 600 35 60])
  axis(handles.axes10,[0 600 10 25])
  set(handles.axes10,'xtick',[])
  
set(handles.grid_on,'checked','off')
set(handles.grid_off,'checked','on')
    
clear all


% --------------------------------------------------------------------
function Untitled_6_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function high_alarm_Callback(hObject, eventdata, handles)
% hObject    handle to high_alarm (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
  prompt={'High Alram Displays At Level : '};
   name=' High Alarm Limit ';
   numlines=1;
   defaultanswer={get(handles.high_alarm_hidden,'string')};
   answer=inputdlg(prompt,name,numlines,defaultanswer);
   if size(answer)==[0 0]
       return
   end

set(handles.high_alarm_hidden,'string',str2double(answer{1}));

% --------------------------------------------------------------------
function low_alarm_Callback(hObject, eventdata, handles)
% hObject    handle to low_alarm (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
  prompt={'Low Alram Displays At Level : '};
   name='Low Alarm Limit ';
   numlines=1;
   defaultanswer={get(handles.low_alarm_hidden,'string')};
   answer=inputdlg(prompt,name,numlines,defaultanswer);
   if size(answer)==[0 0]
       return
   end

set(handles.low_alarm_hidden,'string',str2double(answer{1}));


% --------------------------------------------------------------------
function itae_P_Callback(hObject, eventdata, handles)
% hObject    handle to itae_P (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global tow_for_tunning_parameters
global k_for_tunning_parameters
global deadtime_for_tunning_parameters


if str2double(get(handles.choose_model_history,'string'))~=1
 errordlg('You Should First Derive A Model For System With Puls Test And Fit Model Menu', ' Error: ');
 return 
end

if str2double(get(handles.first_order_flag,'string'))==1 || str2double(get(handles.second_order_flag,'string'))==1 ...
        || str2double(get(handles.sopd_flag,'string'))==1 
 errordlg('ITAE Method Is Only Available For First Order Plus Dead Time Model. ', ' Error: ');
  return 
end

   prompt={' Controller Gain Minimum Limit : ',' Controller Gain Maximum Limit : '};
   name=' Bonuds : ';
   numlines=1;
% reading default answers from 4 hidden texts:
     defaultanswer={get(handles.k_minimum_hidden,'string'),get(handles.k_maximum_hidden,'string')};
   answer=inputdlg(prompt,name,numlines,defaultanswer,'on');
   if size(answer)==[0 0]
       return
   end
   
   if str2double(answer{2}) <= str2double(answer{1})
       uiwait( errordlg(' Maximum Limit Should Be Greater Than Minimum! ' ))
       itae_P_Callback(hObject, eventdata, handles)
       return
   end
  
   
  % I`m going to write new inputs in 4 hidden static texts to be saved for
    % next use:
   set(handles.k_minimum_hidden,'string',str2double(answer{1}))
   set(handles.k_maximum_hidden,'string',str2double(answer{2})) 
   
    k_minimum=str2double(answer{1});
    k_maximum=str2double(answer{2});

    
set(handles.contoroller_gain_text_paramaters,'visible','off');
set(handles.controller_gain_number,'visible','off');

set(handles.reset_time_text_paramaters,'visible','off');
set(handles.reset_time_number,'visible','off');

set(handles.derive_time_text_paramaters,'visible','off');
set(handles.derive_time_number,'visible','off');

set(handles.title_for_parameters,'visible','off');
pause(0.0001)

set(handles.title_for_parameters,'string', ' Waiting . . . ');
set(handles.title_for_parameters,'visible' , 'on' );
pause(0.0001);

model=tf( k_for_tunning_parameters,[tow_for_tunning_parameters 1],'inputdelay', deadtime_for_tunning_parameters);

model=ss(model);
s=1000000000000000000;
for k=k_minimum:0.1:k_maximum
        c=k;
        forward=series(c,model);
        closedloop=feedback(forward,1);
        [yy,tt]=step(closedloop,800);
        deltat=tt(3)-tt(2);
        deltat=linspace(deltat,deltat,length(yy));
        deltat=transpose(deltat);
        error=1-yy;
        itae=deltat.*abs(error);
        temp=sum(itae);
        if temp <= min(s)
            K=k;
        end
        s=[s temp];
end

set(handles.title_for_parameters,'string', ' IAE method P Only :');

set(handles.contoroller_gain_text_paramaters,'visible' , 'on' );
set(handles.controller_gain_number,'string',K);
set(handles.controller_gain_number,'visible' , 'on' );


% --------------------------------------------------------------------
function itae_PI_Callback(hObject, eventdata, handles)
% hObject    handle to itae_PI (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global tow_for_tunning_parameters
global k_for_tunning_parameters
global deadtime_for_tunning_parameters


if str2double(get(handles.choose_model_history,'string'))~=1
 errordlg('You Should First Derive A Model For System With Puls Test And Fit Model Menu', ' Error: ');
 return 
end

if str2double(get(handles.first_order_flag,'string'))==1 || str2double(get(handles.second_order_flag,'string'))==1 ...
        || str2double(get(handles.sopd_flag,'string'))==1 
 errordlg('ITAE Method Is Only Available For First Order Plus Dead Time Model. ', ' Error: ');
  return 
end

   prompt={' Controller Gain Minimum Limit : ',' Controller Gain Maximum Limit : ', ' Reset Time Minimum Limit (sec) : ' , ' Reset Time Maximum Limit (sec) : ' };
   name=' Bonuds : ';
   numlines=1;
% reading default answers from 4 hidden texts:
     defaultanswer={get(handles.k_minimum_hidden,'string'),get(handles.k_maximum_hidden,'string'),get(handles.r_time_minimum_hidden,'string'),get(handles.r_time_maximum_hidden,'string')};
     
   answer=inputdlg(prompt,name,numlines,defaultanswer,'on');
   if size(answer)==[0 0]
       return
   end
   
   if str2double(answer{2}) <= str2double(answer{1}) | str2double(answer{4}) <= str2double(answer{3})
        % uiwait :
       % UIWAIT(FIG) blocks execution until either UIRESUME is called or
       % th
       uiwait( errordlg(' Maximum Limit Should Be Greater Than Minimum! ' ))
       itae_PI_Callback(hObject, eventdata, handles)
       return
   end
  
   
  % I`m going to write new inputs in 4 hidden static texts to be saved for
    % next use:
   set(handles.k_minimum_hidden,'string',str2double(answer{1}))
   set(handles.k_maximum_hidden,'string',str2double(answer{2}))
   set(handles.r_time_minimum_hidden,'string',str2double(answer{3}))
   set(handles.r_time_maximum_hidden,'string',str2double(answer{4}))
   
   
    k_minimum=str2double(answer{1});
    k_maximum=str2double(answer{2});
    r_time_minimum=str2double(answer{3});
    r_time_maximum=str2double(answer{4});
    
set(handles.contoroller_gain_text_paramaters,'visible','off');
set(handles.controller_gain_number,'visible','off');

set(handles.reset_time_text_paramaters,'visible','off');
set(handles.reset_time_number,'visible','off');

set(handles.derive_time_text_paramaters,'visible','off');
set(handles.derive_time_number,'visible','off');

set(handles.title_for_parameters,'visible','off');
pause(0.0001)
set(handles.title_for_parameters,'string', ' Waiting . . . ');

set(handles.title_for_parameters,'visible' , 'on' );
pause(0.0001);

model=tf( k_for_tunning_parameters,[tow_for_tunning_parameters 1],'inputdelay', deadtime_for_tunning_parameters);

model=ss(model);
s=1000000000000000000;
for k=k_minimum:0.1:k_maximum
    for reset_time=r_time_minimum:r_time_maximum
        c=tf([k*reset_time k],[reset_time 0]);
        forward=series(c,model);
        closedloop=feedback(forward,1);
        [yy,tt]=step(closedloop,800);
        deltat=tt(3)-tt(2);
        deltat=linspace(deltat,deltat,length(yy));
        deltat=transpose(deltat);
        error=1-yy;
        itae=deltat.*abs(error);
        temp=sum(itae);
        if temp <= min(s)
            K=k;
            Reset_Time=reset_time;
        end
        s=[s temp];
    end
end

set(handles.title_for_parameters,'string', ' IAE method PI Parameters :');

set(handles.contoroller_gain_text_paramaters,'visible' , 'on' );
set(handles.controller_gain_number,'string',K);
set(handles.controller_gain_number,'visible' , 'on' );
set(handles.reset_time_text_paramaters,'visible' , 'on' );
set(handles.reset_time_number,'string',Reset_Time);
set(handles.reset_time_number,'visible' , 'on' );


% --------------------------------------------------------------------
function itae_PID_Callback(hObject, eventdata, handles)
% hObject    handle to itae_PID (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global tow_for_tunning_parameters
global k_for_tunning_parameters
global deadtime_for_tunning_parameters


if str2double(get(handles.choose_model_history,'string'))~=1
 errordlg('You Should First Derive A Model For System With Puls Test And Fit Model Menu', ' Error: ');
 return 
end

if str2double(get(handles.first_order_flag,'string'))==1 || str2double(get(handles.second_order_flag,'string'))==1 ...
        || str2double(get(handles.sopd_flag,'string'))==1 
 errordlg('ITAE Method Is Only Available For First Order Plus Dead Time Model. ', ' Error: ');
  return 
end

   prompt={' Controller Gain Minimum Limit : ',' Controller Gain Maximum Limit : ', ' Reset Time Minimum Limit (sec) : ' , ' Reset Time Maximum Limit (sec) : ' ...
       , ' Derive Time Minimum Limit (sec) : ' , ' Derive Time Maximum Limit (sec) : ' };
   name=' Bonuds : ';
   numlines=1;
% reading default answers from 4 hidden texts:
     defaultanswer={get(handles.k_minimum_hidden,'string'),get(handles.k_maximum_hidden,'string'),get(handles.r_time_minimum_hidden,'string'),get(handles.r_time_maximum_hidden,'string')...
         get(handles.d_time_minimum_hidden,'string'),get(handles.d_time_maximum_hidden,'string')};
     
   answer=inputdlg(prompt,name,numlines,defaultanswer,'on');
   if size(answer)==[0 0]
       return
   end
   
   if str2double(answer{2}) <= str2double(answer{1}) || str2double(answer{4}) <= str2double(answer{3}) ...
           || str2double(answer{6}) <= str2double(answer{5})
        % uiwait :
       % UIWAIT(FIG) blocks execution until either UIRESUME is called or
       % th
       uiwait( errordlg(' Maximum Limit Should Be Greater Than Minimum! ' ))
        itae_PID_Callback(hObject, eventdata, handles)
       return
   end
  
   
  % I`m going to write new inputs in 4 hidden static texts to be saved for
    % next use:
   set(handles.k_minimum_hidden,'string',str2double(answer{1}))
   set(handles.k_maximum_hidden,'string',str2double(answer{2}))
   set(handles.r_time_minimum_hidden,'string',str2double(answer{3}))
   set(handles.r_time_maximum_hidden,'string',str2double(answer{4}))
   set(handles.d_time_minimum_hidden,'string',str2double(answer{5}))
   set(handles.d_time_maximum_hidden,'string',str2double(answer{6}))
   
    k_minimum=str2double(answer{1});
    k_maximum=str2double(answer{2});
    r_time_minimum=str2double(answer{3});
    r_time_maximum=str2double(answer{4});
    d_time_minimum=str2double(answer{5});
    d_time_maximum=str2double(answer{6});
    
    
set(handles.contoroller_gain_text_paramaters,'visible','off');
set(handles.controller_gain_number,'visible','off');

set(handles.reset_time_text_paramaters,'visible','off');
set(handles.reset_time_number,'visible','off');

set(handles.derive_time_text_paramaters,'visible','off');
set(handles.derive_time_number,'visible','off');

set(handles.title_for_parameters,'visible','off');
pause(0.0001)
set(handles.title_for_parameters,'string', ' Waiting . . . ');

set(handles.title_for_parameters,'visible' , 'on' );
pause(0.0001);

model=tf( k_for_tunning_parameters,[tow_for_tunning_parameters 1],'inputdelay', deadtime_for_tunning_parameters);
model=pade(model,1);
model=ss(model);

s=1000000000000000000;
for k=k_minimum:0.2:k_maximum
    for reset_time=r_time_minimum:2:r_time_maximum
        for derive_time=d_time_minimum:2:d_time_maximum
            
        c=tf([k*reset_time*derive_time k*reset_time k],[reset_time 0]);
        forward=series(c,model);
        closedloop=feedback(forward,1);
        [yy,tt]=step(closedloop,800);
        deltat=tt(3)-tt(2);
        deltat=linspace(deltat,deltat,length(yy));
        deltat=transpose(deltat);
        error=1-yy;
        itae=deltat.*abs(error);
        temp=sum(itae);
        if temp <= min(s)
            K=k;
            Reset_Time=reset_time;
            Derive_Time=derive_time;
        end
        s=[s temp];
        end
    end
end

set(handles.title_for_parameters,'string', ' IAE method PID Parameters :');

set(handles.contoroller_gain_text_paramaters,'visible' , 'on' );
set(handles.controller_gain_number,'string',K);
set(handles.controller_gain_number,'visible' , 'on' );

set(handles.reset_time_text_paramaters,'visible' , 'on' );
set(handles.reset_time_number,'string',Reset_Time);
set(handles.reset_time_number,'visible' , 'on' );

set(handles.derive_time_text_paramaters,'visible' , 'on' );
set(handles.derive_time_number,'string',Derive_Time);
set(handles.derive_time_number,'visible' , 'on' );


% --------------------------------------------------------------------
function Untitled_7_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function grid_on_Callback(hObject, eventdata, handles)
% hObject    handle to grid_on (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.grid_on,'checked','on')
set(handles.grid_off,'checked','off')
         set(handles.axes1,'ygrid','on')
         set(handles.axes1,'xgrid','on')
         
         set(handles.axes10,'ygrid','on')
         set(handles.axes10,'xgrid','on')

% --------------------------------------------------------------------
function grid_off_Callback(hObject, eventdata, handles)
% hObject    handle to grid_off (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.grid_on,'checked','off')
set(handles.grid_off,'checked','on')
         set(handles.axes1,'ygrid','off')
         set(handles.axes1,'xgrid','off')
         
         set(handles.axes10,'ygrid','off')
         set(handles.axes10,'xgrid','off')
